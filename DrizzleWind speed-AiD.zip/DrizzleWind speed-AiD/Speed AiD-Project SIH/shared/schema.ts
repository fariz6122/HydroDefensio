import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, decimal, boolean, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"), // user, health_official, admin
  firstName: text("first_name"),
  lastName: text("last_name"),
  phone: text("phone"),
  location: text("location"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  notificationPreferences: jsonb("notification_preferences").$type<{
    sms: boolean;
    email: boolean;
    whatsapp: boolean;
    push: boolean;
  }>().default({ sms: true, email: true, whatsapp: false, push: true }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Diseases table
export const diseases = pgTable("diseases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  symptoms: jsonb("symptoms").$type<string[]>().default([]),
  prevention: text("prevention"),
  treatment: text("treatment"),
  severity: text("severity").notNull(), // low, medium, high, critical
  isWaterborne: boolean("is_waterborne").default(true),
  incubationPeriod: text("incubation_period"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Disease cases table
export const diseaseCases = pgTable("disease_cases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  diseaseId: varchar("disease_id").notNull().references(() => diseases.id),
  userId: varchar("user_id").references(() => users.id),
  location: text("location").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  status: text("status").notNull().default("suspected"), // suspected, confirmed, recovered, deceased
  reportedDate: timestamp("reported_date").defaultNow(),
  confirmedDate: timestamp("confirmed_date"),
  symptoms: jsonb("symptoms").$type<string[]>().default([]),
  severity: text("severity").notNull(),
  source: text("source").default("user_report"), // user_report, hospital, government
  createdAt: timestamp("created_at").defaultNow(),
});

// Hospitals table
export const hospitals = pgTable("hospitals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  address: text("address").notNull(),
  phone: text("phone"),
  email: text("email"),
  website: text("website"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  type: text("type").notNull(), // government, private, clinic, specialized
  services: jsonb("services").$type<string[]>().default([]),
  capacity: integer("capacity"),
  currentOccupancy: integer("current_occupancy").default(0),
  specializations: jsonb("specializations").$type<string[]>().default([]),
  emergencyServices: boolean("emergency_services").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Appointments table
export const appointments = pgTable("appointments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  hospitalId: varchar("hospital_id").notNull().references(() => hospitals.id),
  appointmentDate: timestamp("appointment_date").notNull(),
  purpose: text("purpose").notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled, confirmed, completed, cancelled
  notes: text("notes"),
  doctorName: text("doctor_name"),
  department: text("department"),
  reminderSent: boolean("reminder_sent").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Water quality monitoring
export const waterQualityData = pgTable("water_quality_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sensorId: text("sensor_id").notNull(),
  location: text("location").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  ph: decimal("ph", { precision: 3, scale: 1 }),
  turbidity: decimal("turbidity", { precision: 5, scale: 2 }),
  dissolvedOxygen: decimal("dissolved_oxygen", { precision: 4, scale: 1 }),
  ecoliCount: integer("ecoli_count"),
  temperature: decimal("temperature", { precision: 4, scale: 1 }),
  conductivity: decimal("conductivity", { precision: 8, scale: 2 }),
  totalColiform: integer("total_coliform"),
  chlorine: decimal("chlorine", { precision: 4, scale: 2 }),
  timestamp: timestamp("timestamp").defaultNow(),
  status: text("status").default("active"), // active, maintenance, offline
});

// Risk areas
export const riskAreas = pgTable("risk_areas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  radius: decimal("radius", { precision: 8, scale: 2 }).notNull(), // in kilometers
  riskLevel: text("risk_level").notNull(), // low, medium, high, critical
  affectedDiseases: jsonb("affected_diseases").$type<string[]>().default([]),
  population: integer("population"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  isActive: boolean("is_active").default(true),
});

// Notifications/Alerts
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // alert, reminder, info, emergency
  priority: text("priority").notNull().default("medium"), // low, medium, high, critical
  channels: jsonb("channels").$type<string[]>().default([]), // sms, email, whatsapp, push
  status: text("status").default("pending"), // pending, sent, delivered, failed
  targetAudience: text("target_audience").default("individual"), // individual, area, all
  riskAreaId: varchar("risk_area_id").references(() => riskAreas.id),
  metadata: jsonb("metadata"),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Health diary entries
export const healthDiaryEntries = pgTable("health_diary_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  symptoms: jsonb("symptoms").$type<string[]>().default([]),
  severityLevel: integer("severity_level").default(1), // 1-10 scale
  waterConsumption: decimal("water_consumption", { precision: 4, scale: 1 }), // liters
  waterSource: text("water_source"),
  foodIntake: text("food_intake"),
  activities: text("activities"),
  mood: text("mood"),
  notes: text("notes"),
  location: text("location"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Weather data
export const weatherData = pgTable("weather_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  location: text("location").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  temperature: decimal("temperature", { precision: 4, scale: 1 }),
  humidity: decimal("humidity", { precision: 4, scale: 1 }),
  rainfall: decimal("rainfall", { precision: 6, scale: 2 }),
  windSpeed: decimal("wind_speed", { precision: 4, scale: 1 }),
  pressure: decimal("pressure", { precision: 7, scale: 2 }),
  conditions: text("conditions"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  diseaseCases: many(diseaseCases),
  appointments: many(appointments),
  notifications: many(notifications),
  healthDiaryEntries: many(healthDiaryEntries),
}));

export const diseasesRelations = relations(diseases, ({ many }) => ({
  diseaseCases: many(diseaseCases),
}));

export const diseaseCasesRelations = relations(diseaseCases, ({ one }) => ({
  disease: one(diseases, {
    fields: [diseaseCases.diseaseId],
    references: [diseases.id],
  }),
  user: one(users, {
    fields: [diseaseCases.userId],
    references: [users.id],
  }),
}));

export const hospitalsRelations = relations(hospitals, ({ many }) => ({
  appointments: many(appointments),
}));

export const appointmentsRelations = relations(appointments, ({ one }) => ({
  user: one(users, {
    fields: [appointments.userId],
    references: [users.id],
  }),
  hospital: one(hospitals, {
    fields: [appointments.hospitalId],
    references: [hospitals.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
  riskArea: one(riskAreas, {
    fields: [notifications.riskAreaId],
    references: [riskAreas.id],
  }),
}));

export const healthDiaryEntriesRelations = relations(healthDiaryEntries, ({ one }) => ({
  user: one(users, {
    fields: [healthDiaryEntries.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertDiseaseSchema = createInsertSchema(diseases).omit({
  id: true,
  createdAt: true,
});

export const insertDiseaseCaseSchema = createInsertSchema(diseaseCases).omit({
  id: true,
  createdAt: true,
});

export const insertHospitalSchema = createInsertSchema(hospitals).omit({
  id: true,
  createdAt: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
});

export const insertWaterQualityDataSchema = createInsertSchema(waterQualityData).omit({
  id: true,
  timestamp: true,
});

export const insertRiskAreaSchema = createInsertSchema(riskAreas).omit({
  id: true,
  lastUpdated: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
  sentAt: true,
});

export const insertHealthDiaryEntrySchema = createInsertSchema(healthDiaryEntries).omit({
  id: true,
  createdAt: true,
});

export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({
  id: true,
  timestamp: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Disease = typeof diseases.$inferSelect;
export type InsertDisease = z.infer<typeof insertDiseaseSchema>;
export type DiseaseCase = typeof diseaseCases.$inferSelect;
export type InsertDiseaseCase = z.infer<typeof insertDiseaseCaseSchema>;
export type Hospital = typeof hospitals.$inferSelect;
export type InsertHospital = z.infer<typeof insertHospitalSchema>;
export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type WaterQualityData = typeof waterQualityData.$inferSelect;
export type InsertWaterQualityData = z.infer<typeof insertWaterQualityDataSchema>;
export type RiskArea = typeof riskAreas.$inferSelect;
export type InsertRiskArea = z.infer<typeof insertRiskAreaSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type HealthDiaryEntry = typeof healthDiaryEntries.$inferSelect;
export type InsertHealthDiaryEntry = z.infer<typeof insertHealthDiaryEntrySchema>;
export type WeatherData = typeof weatherData.$inferSelect;
export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;
