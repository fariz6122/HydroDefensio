import { MailService } from '@sendgrid/mail';

const sendGridApiKey = process.env.SENDGRID_API_KEY || 'mock-sendgrid-key';
const twilioAccountSid = process.env.TWILIO_ACCOUNT_SID || 'mock-twilio-sid';
const twilioAuthToken = process.env.TWILIO_AUTH_TOKEN || 'mock-twilio-token';
const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER || '+1234567890';
const whatsappApiKey = process.env.WHATSAPP_API_KEY || 'mock-whatsapp-key';

// Initialize SendGrid
const mailService = new MailService();
mailService.setApiKey(sendGridApiKey);

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

interface SMSParams {
  to: string;
  message: string;
}

interface WhatsAppParams {
  to: string;
  message: string;
  template?: string;
}

export class CommunicationService {
  async sendEmail(params: EmailParams): Promise<boolean> {
    try {
      if (sendGridApiKey === 'mock-sendgrid-key') {
        console.log('Mock Email sent:', params);
        return true;
      }

      await mailService.send({
        to: params.to,
        from: params.from,
        subject: params.subject,
        text: params.text || "",
        html: params.html,
      });
      
      console.log(`Email sent to ${params.to}: ${params.subject}`);
      return true;
    } catch (error) {
      console.error('SendGrid email error:', error);
      return false;
    }
  }

  async sendSMS(params: SMSParams): Promise<boolean> {
    try {
      if (twilioAccountSid === 'mock-twilio-sid') {
        console.log('Mock SMS sent:', params);
        return true;
      }

      // Twilio SMS implementation
      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${Buffer.from(`${twilioAccountSid}:${twilioAuthToken}`).toString('base64')}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: twilioPhoneNumber,
          To: params.to,
          Body: params.message,
        }),
      });

      if (response.ok) {
        console.log(`SMS sent to ${params.to}`);
        return true;
      } else {
        console.error('Twilio SMS error:', await response.text());
        return false;
      }
    } catch (error) {
      console.error('SMS error:', error);
      return false;
    }
  }

  async sendWhatsAppMessage(params: WhatsAppParams): Promise<boolean> {
    try {
      if (whatsappApiKey === 'mock-whatsapp-key') {
        console.log('Mock WhatsApp message sent:', params);
        return true;
      }

      // WhatsApp Business API implementation (using a generic endpoint)
      const response = await fetch('https://graph.facebook.com/v17.0/YOUR_PHONE_NUMBER_ID/messages', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${whatsappApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: params.to,
          type: 'text',
          text: {
            body: params.message,
          },
        }),
      });

      if (response.ok) {
        console.log(`WhatsApp message sent to ${params.to}`);
        return true;
      } else {
        console.error('WhatsApp API error:', await response.text());
        return false;
      }
    } catch (error) {
      console.error('WhatsApp error:', error);
      return false;
    }
  }

  async sendEmergencyAlert(message: string, recipients: { email?: string; phone?: string; whatsapp?: string; channels: string[] }[]): Promise<{
    email: number;
    sms: number;
    whatsapp: number;
    total: number;
  }> {
    let emailCount = 0;
    let smsCount = 0;
    let whatsappCount = 0;

    for (const recipient of recipients) {
      if (recipient.channels.includes('email') && recipient.email) {
        const success = await this.sendEmail({
          to: recipient.email,
          from: 'alerts@speedaid.org',
          subject: 'EMERGENCY HEALTH ALERT - SPEED AiD',
          text: message,
          html: `<h2 style="color: #dc2626;">EMERGENCY HEALTH ALERT</h2><p>${message}</p><br><p><em>This is an automated message from SPEED AiD Waterborne Disease Monitoring System.</em></p>`,
        });
        if (success) emailCount++;
      }

      if (recipient.channels.includes('sms') && recipient.phone) {
        const success = await this.sendSMS({
          to: recipient.phone,
          message: `EMERGENCY ALERT: ${message} - SPEED AiD`,
        });
        if (success) smsCount++;
      }

      if (recipient.channels.includes('whatsapp') && recipient.whatsapp) {
        const success = await this.sendWhatsAppMessage({
          to: recipient.whatsapp,
          message: `🚨 EMERGENCY HEALTH ALERT\n\n${message}\n\nFrom: SPEED AiD Disease Monitoring System`,
        });
        if (success) whatsappCount++;
      }
    }

    return {
      email: emailCount,
      sms: smsCount,
      whatsapp: whatsappCount,
      total: emailCount + smsCount + whatsappCount,
    };
  }

  async sendAppointmentReminder(appointment: {
    patientEmail: string;
    patientPhone?: string;
    hospitalName: string;
    appointmentDate: Date;
    doctorName?: string;
    department?: string;
  }): Promise<boolean> {
    const dateStr = appointment.appointmentDate.toLocaleDateString('en-IN', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const message = `Reminder: You have an appointment at ${appointment.hospitalName} on ${dateStr}${appointment.doctorName ? ` with Dr. ${appointment.doctorName}` : ''}${appointment.department ? ` (${appointment.department})` : ''}. Please arrive 15 minutes early.`;

    const emailSuccess = await this.sendEmail({
      to: appointment.patientEmail,
      from: 'appointments@speedaid.org',
      subject: 'Appointment Reminder - SPEED AiD',
      text: message,
      html: `
        <h2>Appointment Reminder</h2>
        <p><strong>Hospital:</strong> ${appointment.hospitalName}</p>
        <p><strong>Date & Time:</strong> ${dateStr}</p>
        ${appointment.doctorName ? `<p><strong>Doctor:</strong> Dr. ${appointment.doctorName}</p>` : ''}
        ${appointment.department ? `<p><strong>Department:</strong> ${appointment.department}</p>` : ''}
        <p>Please arrive 15 minutes early.</p>
        <br>
        <p><em>From SPEED AiD Waterborne Disease Monitoring System</em></p>
      `,
    });

    if (appointment.patientPhone) {
      await this.sendSMS({
        to: appointment.patientPhone,
        message: `Appointment Reminder: ${message}`,
      });
    }

    return emailSuccess;
  }
}

export const communicationService = new CommunicationService();
