const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY || 'mock-weather-key';
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

export interface WeatherResponse {
  location: string;
  latitude: number;
  longitude: number;
  temperature: number;
  humidity: number;
  rainfall: number;
  windSpeed: number;
  pressure: number;
  conditions: string;
  timestamp: Date;
}

export class WeatherService {
  async getCurrentWeather(latitude: number, longitude: number): Promise<WeatherResponse | null> {
    try {
      if (OPENWEATHER_API_KEY === 'mock-weather-key') {
        // Return mock data for development
        return {
          location: 'Northeast India',
          latitude,
          longitude,
          temperature: 28.5 + (Math.random() - 0.5) * 10,
          humidity: 75 + (Math.random() - 0.5) * 20,
          rainfall: Math.random() * 5,
          windSpeed: 5 + Math.random() * 10,
          pressure: 1013 + (Math.random() - 0.5) * 20,
          conditions: ['Clear', 'Cloudy', 'Rainy', 'Partly Cloudy'][Math.floor(Math.random() * 4)],
          timestamp: new Date(),
        };
      }

      const response = await fetch(
        `${BASE_URL}/weather?lat=${latitude}&lon=${longitude}&appid=${OPENWEATHER_API_KEY}&units=metric`
      );

      if (!response.ok) {
        throw new Error(`Weather API error: ${response.status}`);
      }

      const data = await response.json();

      return {
        location: data.name || 'Unknown',
        latitude,
        longitude,
        temperature: data.main.temp,
        humidity: data.main.humidity,
        rainfall: data.rain?.['1h'] || 0,
        windSpeed: data.wind.speed,
        pressure: data.main.pressure,
        conditions: data.weather[0].description,
        timestamp: new Date(),
      };
    } catch (error) {
      console.error('Weather service error:', error);
      return null;
    }
  }

  async getWeatherForecast(latitude: number, longitude: number, days = 5): Promise<WeatherResponse[]> {
    try {
      if (OPENWEATHER_API_KEY === 'mock-weather-key') {
        // Return mock forecast data
        return Array.from({ length: days }, (_, i) => ({
          location: 'Northeast India',
          latitude,
          longitude,
          temperature: 25 + Math.random() * 10,
          humidity: 70 + Math.random() * 20,
          rainfall: Math.random() * 10,
          windSpeed: 3 + Math.random() * 8,
          pressure: 1010 + Math.random() * 15,
          conditions: ['Clear', 'Cloudy', 'Rainy', 'Partly Cloudy'][Math.floor(Math.random() * 4)],
          timestamp: new Date(Date.now() + i * 24 * 60 * 60 * 1000),
        }));
      }

      const response = await fetch(
        `${BASE_URL}/forecast?lat=${latitude}&lon=${longitude}&appid=${OPENWEATHER_API_KEY}&units=metric&cnt=${days * 8}`
      );

      if (!response.ok) {
        throw new Error(`Weather forecast API error: ${response.status}`);
      }

      const data = await response.json();

      return data.list.map((item: any) => ({
        location: data.city.name,
        latitude,
        longitude,
        temperature: item.main.temp,
        humidity: item.main.humidity,
        rainfall: item.rain?.['3h'] || 0,
        windSpeed: item.wind.speed,
        pressure: item.main.pressure,
        conditions: item.weather[0].description,
        timestamp: new Date(item.dt * 1000),
      }));
    } catch (error) {
      console.error('Weather forecast error:', error);
      return [];
    }
  }

  async analyzeWeatherDiseaseCorrelation(weatherData: WeatherResponse[], diseaseCases: any[]): Promise<{
    riskScore: number;
    factors: string[];
    recommendations: string[];
  }> {
    let riskScore = 0;
    const factors: string[] = [];
    const recommendations: string[] = [];

    // Analyze temperature
    const avgTemp = weatherData.reduce((sum, w) => sum + w.temperature, 0) / weatherData.length;
    if (avgTemp > 30) {
      riskScore += 20;
      factors.push('High temperature increases bacteria growth');
      recommendations.push('Ensure proper water storage and refrigeration');
    }

    // Analyze humidity
    const avgHumidity = weatherData.reduce((sum, w) => sum + w.humidity, 0) / weatherData.length;
    if (avgHumidity > 80) {
      riskScore += 15;
      factors.push('High humidity promotes pathogen survival');
      recommendations.push('Improve ventilation and sanitation practices');
    }

    // Analyze rainfall
    const totalRainfall = weatherData.reduce((sum, w) => sum + w.rainfall, 0);
    if (totalRainfall > 50) {
      riskScore += 25;
      factors.push('Heavy rainfall can contaminate water sources');
      recommendations.push('Avoid untreated water sources during monsoon');
    }

    // Analyze recent disease trends
    const recentCases = diseaseCases.filter(c => 
      new Date(c.reportedDate) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    );

    if (recentCases.length > 10) {
      riskScore += 30;
      factors.push('Increasing disease cases in the area');
      recommendations.push('Seek immediate medical attention for symptoms');
    }

    // Cap risk score at 100
    riskScore = Math.min(100, riskScore);

    return {
      riskScore,
      factors,
      recommendations,
    };
  }
}

export const weatherService = new WeatherService();
