import { storage } from '../storage';

export interface SymptomAssessment {
  symptoms: string[];
  severity: number;
  duration: string;
  age: number;
  location: string;
}

export interface AssessmentResult {
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  possibleDiseases: string[];
  recommendations: string[];
  urgency: 'none' | 'monitor' | 'consult' | 'immediate';
  score: number;
}

export class HealthDataService {
  private symptomDatabase = {
    cholera: {
      symptoms: ['diarrhea', 'vomiting', 'dehydration', 'stomach_cramps', 'nausea'],
      severity: 'high',
      urgency: 'immediate',
    },
    typhoid: {
      symptoms: ['fever', 'headache', 'weakness', 'stomach_pain', 'constipation', 'loss_of_appetite'],
      severity: 'high',
      urgency: 'consult',
    },
    hepatitis_a: {
      symptoms: ['jaundice', 'fatigue', 'nausea', 'stomach_pain', 'loss_of_appetite', 'low_fever'],
      severity: 'medium',
      urgency: 'consult',
    },
    giardiasis: {
      symptoms: ['diarrhea', 'gas', 'stomach_cramps', 'upset_stomach', 'nausea'],
      severity: 'medium',
      urgency: 'monitor',
    },
    dysentery: {
      symptoms: ['bloody_diarrhea', 'fever', 'stomach_cramps', 'nausea'],
      severity: 'high',
      urgency: 'immediate',
    },
    ecoli_infection: {
      symptoms: ['diarrhea', 'stomach_cramps', 'vomiting', 'fever'],
      severity: 'medium',
      urgency: 'consult',
    },
  };

  async assessSymptoms(assessment: SymptomAssessment): Promise<AssessmentResult> {
    let totalScore = 0;
    const matchedDiseases: { disease: string; score: number }[] = [];

    // Check each disease against reported symptoms
    for (const [disease, data] of Object.entries(this.symptomDatabase)) {
      const matchScore = this.calculateSymptomMatch(assessment.symptoms, data.symptoms);
      
      if (matchScore > 0.3) { // 30% minimum match threshold
        let diseaseScore = matchScore * 100;
        
        // Adjust score based on severity and age
        if (data.severity === 'high') diseaseScore *= 1.3;
        if (assessment.age > 65 || assessment.age < 5) diseaseScore *= 1.2;
        if (assessment.severity > 7) diseaseScore *= 1.2;
        
        matchedDiseases.push({ disease, score: diseaseScore });
        totalScore = Math.max(totalScore, diseaseScore);
      }
    }

    // Sort diseases by score
    matchedDiseases.sort((a, b) => b.score - a.score);

    // Determine risk level
    let riskLevel: AssessmentResult['riskLevel'] = 'low';
    let urgency: AssessmentResult['urgency'] = 'none';

    if (totalScore > 80) {
      riskLevel = 'critical';
      urgency = 'immediate';
    } else if (totalScore > 60) {
      riskLevel = 'high';
      urgency = 'consult';
    } else if (totalScore > 40) {
      riskLevel = 'medium';
      urgency = 'monitor';
    }

    // Generate recommendations
    const recommendations = this.generateRecommendations(riskLevel, urgency, matchedDiseases);

    return {
      riskLevel,
      possibleDiseases: matchedDiseases.slice(0, 3).map(m => m.disease.replace('_', ' ')),
      recommendations,
      urgency,
      score: totalScore,
    };
  }

  private calculateSymptomMatch(reportedSymptoms: string[], diseaseSymptoms: string[]): number {
    const matches = reportedSymptoms.filter(symptom => 
      diseaseSymptoms.some(ds => ds.includes(symptom) || symptom.includes(ds))
    );
    
    return matches.length / diseaseSymptoms.length;
  }

  private generateRecommendations(riskLevel: string, urgency: string, diseases: { disease: string; score: number }[]): string[] {
    const recommendations: string[] = [];

    switch (urgency) {
      case 'immediate':
        recommendations.push('Seek immediate medical attention');
        recommendations.push('Go to the nearest emergency room or call emergency services');
        recommendations.push('Stay hydrated with oral rehydration solution');
        break;
      case 'consult':
        recommendations.push('Consult a healthcare provider within 24 hours');
        recommendations.push('Monitor symptoms closely');
        recommendations.push('Maintain proper hydration');
        break;
      case 'monitor':
        recommendations.push('Monitor symptoms for 24-48 hours');
        recommendations.push('Drink plenty of clean, safe water');
        recommendations.push('Rest and avoid solid foods if experiencing nausea');
        break;
      default:
        recommendations.push('Continue monitoring your health');
        recommendations.push('Maintain good hygiene practices');
    }

    // Add disease-specific recommendations
    if (diseases.some(d => d.disease.includes('cholera') || d.disease.includes('dysentery'))) {
      recommendations.push('Avoid all unboiled/untreated water');
      recommendations.push('Use oral rehydration salts (ORS)');
    }

    if (diseases.some(d => d.disease.includes('hepatitis'))) {
      recommendations.push('Avoid alcohol and fatty foods');
      recommendations.push('Get adequate rest');
    }

    recommendations.push('Wash hands frequently with soap and clean water');
    recommendations.push('Avoid street food and uncooked vegetables');

    return recommendations;
  }

  async generateRiskAssessment(userId: string, location: string): Promise<{
    personalRisk: number;
    areaRisk: number;
    overallRisk: number;
    factors: string[];
  }> {
    // Get user's health history
    const healthEntries = await storage.getHealthDiaryEntries(userId);
    const recentEntries = healthEntries.filter(entry => 
      new Date(entry.date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    );

    // Calculate personal risk based on recent symptoms
    let personalRisk = 0;
    const factors: string[] = [];

    if (recentEntries.length > 0) {
      const avgSeverity = recentEntries.reduce((sum, entry) => sum + (entry.severityLevel || 0), 0) / recentEntries.length;
      personalRisk = Math.min(avgSeverity * 10, 100);
      
      if (avgSeverity > 5) {
        factors.push('Recent health issues reported');
      }
    }

    // Get area risk from disease cases and water quality
    const areaCases = await storage.getDiseaseCasesByLocation(26.1445, 91.7362, 50); // Guwahati coordinates as example
    const recentCases = areaCases.filter(caseItem => 
      caseItem.reportedDate && new Date(caseItem.reportedDate) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    );

    let areaRisk = Math.min(recentCases.length * 5, 100);

    if (recentCases.length > 10) {
      factors.push('High number of recent cases in area');
    }

    // Get water quality data
    const waterData = await storage.getWaterQualityByLocation(26.1445, 91.7362, 50);
    if (waterData.length > 0) {
      const latestWater = waterData[0];
      
      if (latestWater.ph && (Number(latestWater.ph) < 6.5 || Number(latestWater.ph) > 8.5)) {
        areaRisk += 10;
        factors.push('Water pH levels outside safe range');
      }
      
      if (latestWater.ecoliCount && Number(latestWater.ecoliCount) > 0) {
        areaRisk += 20;
        factors.push('E. coli detected in water supply');
      }
      
      if (latestWater.turbidity && Number(latestWater.turbidity) > 5) {
        areaRisk += 10;
        factors.push('High water turbidity levels');
      }
    }

    const overallRisk = Math.min((personalRisk * 0.4 + areaRisk * 0.6), 100);

    return {
      personalRisk,
      areaRisk,
      overallRisk,
      factors,
    };
  }

  async simulateWaterQualitySensors(): Promise<void> {
    // Simulate water quality data for key locations in Northeast India
    const locations = [
      { name: 'Brahmaputra River - Guwahati', lat: 26.1445, lng: 91.7362, sensorId: 'GUW-001' },
      { name: 'Barak River - Silchar', lat: 24.8333, lng: 92.7789, sensorId: 'SIL-001' },
      { name: 'Subansiri River - Itanagar', lat: 27.0844, lng: 93.6053, sensorId: 'ITA-001' },
      { name: 'Manipur River - Imphal', lat: 24.8170, lng: 93.9368, sensorId: 'IMP-001' },
      { name: 'Tuirial River - Aizawl', lat: 23.7271, lng: 92.7176, sensorId: 'AIZ-001' },
    ];

    for (const location of locations) {
      const data = {
        sensorId: location.sensorId,
        location: location.name,
        latitude: location.lat.toString(),
        longitude: location.lng.toString(),
        ph: (6.5 + Math.random() * 2).toFixed(1), // pH 6.5-8.5
        turbidity: (Math.random() * 8).toFixed(2), // 0-8 NTU
        dissolvedOxygen: (6 + Math.random() * 4).toFixed(1), // 6-10 mg/L
        ecoliCount: Math.floor(Math.random() * 20), // 0-20 CFU/100ml
        temperature: (20 + Math.random() * 15).toFixed(1), // 20-35°C
        conductivity: (100 + Math.random() * 400).toFixed(2), // 100-500 µS/cm
        totalColiform: Math.floor(Math.random() * 50),
        chlorine: (0.2 + Math.random() * 1.8).toFixed(2), // 0.2-2.0 mg/L
        status: Math.random() > 0.1 ? 'active' : 'maintenance',
      };

      try {
        await storage.createWaterQualityData(data);
      } catch (error) {
        console.error('Error creating water quality data:', error);
      }
    }
  }
}

export const healthDataService = new HealthDataService();
