import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { communicationService } from "./services/communication";
import { weatherService } from "./services/weather";
import { healthDataService } from "./services/health-data";
import { 
  insertUserSchema, insertDiseaseSchema, insertDiseaseCaseSchema, 
  insertHospitalSchema, insertAppointmentSchema, insertNotificationSchema, 
  insertHealthDiaryEntrySchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    
    ws.on('message', (message) => {
      console.log('Received:', message.toString());
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });

    // Send initial connection confirmation
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'connected', message: 'WebSocket connected successfully' }));
    }
  });

  // Broadcast function for real-time updates
  const broadcast = (data: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  };

  // Dashboard and Analytics Routes
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // User Routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.updateUser(req.params.id, req.body);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Disease Routes
  app.get("/api/diseases", async (req, res) => {
    try {
      const diseases = await storage.getDiseases();
      res.json(diseases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch diseases" });
    }
  });

  app.post("/api/diseases", async (req, res) => {
    try {
      const diseaseData = insertDiseaseSchema.parse(req.body);
      const disease = await storage.createDisease(diseaseData);
      res.status(201).json(disease);
    } catch (error) {
      res.status(400).json({ message: "Invalid disease data" });
    }
  });

  // Disease Cases Routes
  app.get("/api/disease-cases", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const cases = await storage.getDiseaseCases(limit);
      res.json(cases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch disease cases" });
    }
  });

  app.get("/api/disease-cases/location", async (req, res) => {
    try {
      const { latitude, longitude, radius } = req.query;
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude required" });
      }
      
      const cases = await storage.getDiseaseCasesByLocation(
        parseFloat(latitude as string),
        parseFloat(longitude as string),
        parseFloat(radius as string) || 10
      );
      res.json(cases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch disease cases by location" });
    }
  });

  app.post("/api/disease-cases", async (req, res) => {
    try {
      const caseData = insertDiseaseCaseSchema.parse(req.body);
      const diseaseCase = await storage.createDiseaseCase(caseData);
      
      // Broadcast new case to connected clients
      broadcast({
        type: 'new_disease_case',
        data: diseaseCase
      });
      
      res.status(201).json(diseaseCase);
    } catch (error) {
      res.status(400).json({ message: "Invalid disease case data" });
    }
  });

  // Hospitals Routes
  app.get("/api/hospitals", async (req, res) => {
    try {
      const hospitals = await storage.getHospitals();
      res.json(hospitals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch hospitals" });
    }
  });

  app.get("/api/hospitals/location", async (req, res) => {
    try {
      const { latitude, longitude, radius } = req.query;
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude required" });
      }
      
      const hospitals = await storage.getHospitalsByLocation(
        parseFloat(latitude as string),
        parseFloat(longitude as string),
        parseFloat(radius as string) || 50
      );
      res.json(hospitals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch hospitals by location" });
    }
  });

  app.post("/api/hospitals", async (req, res) => {
    try {
      const hospitalData = insertHospitalSchema.parse(req.body);
      const hospital = await storage.createHospital(hospitalData);
      res.status(201).json(hospital);
    } catch (error) {
      res.status(400).json({ message: "Invalid hospital data" });
    }
  });

  // Appointments Routes
  app.get("/api/appointments/:userId", async (req, res) => {
    try {
      const appointments = await storage.getAppointments(req.params.userId);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.post("/api/appointments", async (req, res) => {
    try {
      const appointmentData = insertAppointmentSchema.parse(req.body);
      const appointment = await storage.createAppointment(appointmentData);
      
      // Send appointment confirmation
      const user = await storage.getUser(appointment.userId);
      const hospital = await storage.getHospital(appointment.hospitalId);
      
      if (user && hospital) {
        await communicationService.sendEmail({
          to: user.email,
          from: 'appointments@speedaid.org',
          subject: 'Appointment Confirmed - SPEED AiD',
          text: `Your appointment at ${hospital.name} has been confirmed for ${appointment.appointmentDate}.`,
          html: `
            <h2>Appointment Confirmed</h2>
            <p><strong>Hospital:</strong> ${hospital.name}</p>
            <p><strong>Date:</strong> ${appointment.appointmentDate}</p>
            <p><strong>Purpose:</strong> ${appointment.purpose}</p>
          `
        });
      }
      
      res.status(201).json(appointment);
    } catch (error) {
      res.status(400).json({ message: "Invalid appointment data" });
    }
  });

  // Water Quality Routes
  app.get("/api/water-quality", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const data = await storage.getWaterQualityData(limit);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch water quality data" });
    }
  });

  app.get("/api/water-quality/location", async (req, res) => {
    try {
      const { latitude, longitude, radius } = req.query;
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude required" });
      }
      
      const data = await storage.getWaterQualityByLocation(
        parseFloat(latitude as string),
        parseFloat(longitude as string),
        parseFloat(radius as string) || 50
      );
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch water quality data by location" });
    }
  });

  app.post("/api/water-quality/simulate", async (req, res) => {
    try {
      await healthDataService.simulateWaterQualitySensors();
      
      // Broadcast water quality update
      const latestData = await storage.getWaterQualityData(10);
      broadcast({
        type: 'water_quality_update',
        data: latestData
      });
      
      res.json({ message: "Water quality data simulated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to simulate water quality data" });
    }
  });

  // Risk Areas Routes
  app.get("/api/risk-areas", async (req, res) => {
    try {
      const riskAreas = await storage.getRiskAreas();
      res.json(riskAreas);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch risk areas" });
    }
  });

  // Notifications Routes
  app.get("/api/notifications", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const limit = parseInt(req.query.limit as string) || 50;
      const notifications = await storage.getNotifications(userId, limit);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post("/api/notifications/emergency", async (req, res) => {
    try {
      const { message, targetArea, priority = 'critical' } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Get users in target area or all users
      const users = []; // This would be implemented based on target area logic
      
      // For demo, we'll use mock recipients
      const recipients = [
        {
          email: 'user@example.com',
          phone: '+911234567890',
          whatsapp: '+911234567890',
          channels: ['email', 'sms', 'whatsapp']
        }
      ];

      const result = await communicationService.sendEmergencyAlert(message, recipients);
      
      // Create notification record
      const notification = await storage.createNotification({
        title: 'Emergency Alert',
        message,
        type: 'emergency',
        priority,
        channels: ['email', 'sms', 'whatsapp'],
        status: 'sent',
        targetAudience: targetArea || 'all'
      });

      // Broadcast emergency alert
      broadcast({
        type: 'emergency_alert',
        data: { message, result }
      });

      res.json({ notification, communicationResult: result });
    } catch (error) {
      res.status(500).json({ message: "Failed to send emergency alert" });
    }
  });

  // Health Diary Routes
  app.get("/api/health-diary/:userId", async (req, res) => {
    try {
      const entries = await storage.getHealthDiaryEntries(req.params.userId);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch health diary entries" });
    }
  });

  app.post("/api/health-diary", async (req, res) => {
    try {
      const entryData = insertHealthDiaryEntrySchema.parse(req.body);
      const entry = await storage.createHealthDiaryEntry(entryData);
      res.status(201).json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid health diary entry data" });
    }
  });

  // Symptom Checker Routes
  app.post("/api/symptom-checker/assess", async (req, res) => {
    try {
      const { symptoms, severity, duration, age, location } = req.body;
      
      if (!symptoms || !Array.isArray(symptoms)) {
        return res.status(400).json({ message: "Symptoms array is required" });
      }

      const assessment = await healthDataService.assessSymptoms({
        symptoms,
        severity: severity || 5,
        duration: duration || 'recent',
        age: age || 30,
        location: location || 'unknown'
      });

      res.json(assessment);
    } catch (error) {
      res.status(500).json({ message: "Failed to assess symptoms" });
    }
  });

  app.post("/api/risk-assessment/:userId", async (req, res) => {
    try {
      const { location } = req.body;
      const riskAssessment = await healthDataService.generateRiskAssessment(
        req.params.userId,
        location || 'Northeast India'
      );
      res.json(riskAssessment);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate risk assessment" });
    }
  });

  // Weather Routes
  app.get("/api/weather/current", async (req, res) => {
    try {
      const { latitude, longitude } = req.query;
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude required" });
      }

      const weather = await weatherService.getCurrentWeather(
        parseFloat(latitude as string),
        parseFloat(longitude as string)
      );

      if (!weather) {
        return res.status(404).json({ message: "Weather data not available" });
      }

      // Store weather data (convert coordinates to strings)
      await storage.createWeatherData({
        ...weather,
        latitude: weather.latitude.toString(),
        longitude: weather.longitude.toString()
      });

      res.json(weather);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch weather data" });
    }
  });

  app.get("/api/weather/forecast", async (req, res) => {
    try {
      const { latitude, longitude, days } = req.query;
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude required" });
      }

      const forecast = await weatherService.getWeatherForecast(
        parseFloat(latitude as string),
        parseFloat(longitude as string),
        parseInt(days as string) || 5
      );

      res.json(forecast);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch weather forecast" });
    }
  });

  // Start periodic tasks
  setInterval(async () => {
    try {
      // Simulate water quality sensors every 5 minutes
      await healthDataService.simulateWaterQualitySensors();
      
      // Broadcast latest water quality data
      const latestData = await storage.getWaterQualityData(5);
      broadcast({
        type: 'water_quality_update',
        data: latestData
      });
    } catch (error) {
      console.error('Error in periodic water quality simulation:', error);
    }
  }, 5 * 60 * 1000); // 5 minutes

  return httpServer;
}
