import { 
  users, diseases, diseaseCases, hospitals, appointments, 
  waterQualityData, riskAreas, notifications, healthDiaryEntries, weatherData,
  type User, type InsertUser, type Disease, type InsertDisease,
  type DiseaseCase, type InsertDiseaseCase, type Hospital, type InsertHospital,
  type Appointment, type InsertAppointment, type WaterQualityData, type InsertWaterQualityData,
  type RiskArea, type InsertRiskArea, type Notification, type InsertNotification,
  type HealthDiaryEntry, type InsertHealthDiaryEntry, type WeatherData, type InsertWeatherData
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, like, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;

  // Disease methods
  getDiseases(): Promise<Disease[]>;
  getDisease(id: string): Promise<Disease | undefined>;
  createDisease(disease: InsertDisease): Promise<Disease>;
  
  // Disease case methods
  getDiseaseCases(limit?: number): Promise<DiseaseCase[]>;
  getDiseaseCasesByLocation(latitude: number, longitude: number, radius: number): Promise<DiseaseCase[]>;
  createDiseaseCase(diseaseCase: InsertDiseaseCase): Promise<DiseaseCase>;
  updateDiseaseCase(id: string, diseaseCase: Partial<InsertDiseaseCase>): Promise<DiseaseCase | undefined>;

  // Hospital methods
  getHospitals(): Promise<Hospital[]>;
  getHospital(id: string): Promise<Hospital | undefined>;
  getHospitalsByLocation(latitude: number, longitude: number, radius: number): Promise<Hospital[]>;
  createHospital(hospital: InsertHospital): Promise<Hospital>;
  updateHospital(id: string, hospital: Partial<InsertHospital>): Promise<Hospital | undefined>;

  // Appointment methods
  getAppointments(userId: string): Promise<Appointment[]>;
  getAppointment(id: string): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: string, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined>;

  // Water quality methods
  getWaterQualityData(limit?: number): Promise<WaterQualityData[]>;
  getWaterQualityByLocation(latitude: number, longitude: number, radius: number): Promise<WaterQualityData[]>;
  createWaterQualityData(data: InsertWaterQualityData): Promise<WaterQualityData>;

  // Risk area methods
  getRiskAreas(): Promise<RiskArea[]>;
  getRiskArea(id: string): Promise<RiskArea | undefined>;
  createRiskArea(riskArea: InsertRiskArea): Promise<RiskArea>;
  updateRiskArea(id: string, riskArea: Partial<InsertRiskArea>): Promise<RiskArea | undefined>;

  // Notification methods
  getNotifications(userId?: string, limit?: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  updateNotification(id: string, notification: Partial<InsertNotification>): Promise<Notification | undefined>;

  // Health diary methods
  getHealthDiaryEntries(userId: string): Promise<HealthDiaryEntry[]>;
  createHealthDiaryEntry(entry: InsertHealthDiaryEntry): Promise<HealthDiaryEntry>;

  // Weather methods
  getWeatherData(location: string): Promise<WeatherData[]>;
  createWeatherData(data: InsertWeatherData): Promise<WeatherData>;

  // Analytics methods
  getDashboardStats(): Promise<{
    activeCases: number;
    highRiskAreas: number;
    waterQualityIndex: number;
    hospitalsAvailable: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values([insertUser]).returning();
    return user;
  }

  async updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users).set(user).where(eq(users.id, id)).returning();
    return updatedUser || undefined;
  }

  async getDiseases(): Promise<Disease[]> {
    return await db.select().from(diseases).orderBy(diseases.name);
  }

  async getDisease(id: string): Promise<Disease | undefined> {
    const [disease] = await db.select().from(diseases).where(eq(diseases.id, id));
    return disease || undefined;
  }

  async createDisease(disease: InsertDisease): Promise<Disease> {
    const [newDisease] = await db.insert(diseases).values([disease]).returning();
    return newDisease;
  }

  async getDiseaseCases(limit = 100): Promise<DiseaseCase[]> {
    return await db.select().from(diseaseCases)
      .orderBy(desc(diseaseCases.reportedDate))
      .limit(limit);
  }

  async getDiseaseCasesByLocation(latitude: number, longitude: number, radius: number): Promise<DiseaseCase[]> {
    return await db.select().from(diseaseCases)
      .where(sql`
        ST_DWithin(
          ST_MakePoint(${diseaseCases.longitude}, ${diseaseCases.latitude})::geography,
          ST_MakePoint(${longitude}, ${latitude})::geography,
          ${radius * 1000}
        )
      `)
      .orderBy(desc(diseaseCases.reportedDate));
  }

  async createDiseaseCase(diseaseCase: InsertDiseaseCase): Promise<DiseaseCase> {
    const [newCase] = await db.insert(diseaseCases).values([diseaseCase]).returning();
    return newCase;
  }

  async updateDiseaseCase(id: string, diseaseCase: Partial<InsertDiseaseCase>): Promise<DiseaseCase | undefined> {
    const [updatedCase] = await db.update(diseaseCases).set(diseaseCase).where(eq(diseaseCases.id, id)).returning();
    return updatedCase || undefined;
  }

  async getHospitals(): Promise<Hospital[]> {
    return await db.select().from(hospitals).where(eq(hospitals.isActive, true)).orderBy(hospitals.name);
  }

  async getHospital(id: string): Promise<Hospital | undefined> {
    const [hospital] = await db.select().from(hospitals).where(eq(hospitals.id, id));
    return hospital || undefined;
  }

  async getHospitalsByLocation(latitude: number, longitude: number, radius: number): Promise<Hospital[]> {
    return await db.select().from(hospitals)
      .where(and(
        eq(hospitals.isActive, true),
        sql`
          ST_DWithin(
            ST_MakePoint(${hospitals.longitude}, ${hospitals.latitude})::geography,
            ST_MakePoint(${longitude}, ${latitude})::geography,
            ${radius * 1000}
          )
        `
      ))
      .orderBy(hospitals.name);
  }

  async createHospital(hospital: InsertHospital): Promise<Hospital> {
    const [newHospital] = await db.insert(hospitals).values([hospital]).returning();
    return newHospital;
  }

  async updateHospital(id: string, hospital: Partial<InsertHospital>): Promise<Hospital | undefined> {
    const [updatedHospital] = await db.update(hospitals).set(hospital).where(eq(hospitals.id, id)).returning();
    return updatedHospital || undefined;
  }

  async getAppointments(userId: string): Promise<Appointment[]> {
    return await db.select().from(appointments)
      .where(eq(appointments.userId, userId))
      .orderBy(desc(appointments.appointmentDate));
  }

  async getAppointment(id: string): Promise<Appointment | undefined> {
    const [appointment] = await db.select().from(appointments).where(eq(appointments.id, id));
    return appointment || undefined;
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [newAppointment] = await db.insert(appointments).values([appointment]).returning();
    return newAppointment;
  }

  async updateAppointment(id: string, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    const [updatedAppointment] = await db.update(appointments).set(appointment).where(eq(appointments.id, id)).returning();
    return updatedAppointment || undefined;
  }

  async getWaterQualityData(limit = 100): Promise<WaterQualityData[]> {
    return await db.select().from(waterQualityData)
      .orderBy(desc(waterQualityData.timestamp))
      .limit(limit);
  }

  async getWaterQualityByLocation(latitude: number, longitude: number, radius: number): Promise<WaterQualityData[]> {
    return await db.select().from(waterQualityData)
      .where(sql`
        ST_DWithin(
          ST_MakePoint(${waterQualityData.longitude}, ${waterQualityData.latitude})::geography,
          ST_MakePoint(${longitude}, ${latitude})::geography,
          ${radius * 1000}
        )
      `)
      .orderBy(desc(waterQualityData.timestamp));
  }

  async createWaterQualityData(data: InsertWaterQualityData): Promise<WaterQualityData> {
    const [newData] = await db.insert(waterQualityData).values([data]).returning();
    return newData;
  }

  async getRiskAreas(): Promise<RiskArea[]> {
    return await db.select().from(riskAreas).where(eq(riskAreas.isActive, true)).orderBy(riskAreas.name);
  }

  async getRiskArea(id: string): Promise<RiskArea | undefined> {
    const [riskArea] = await db.select().from(riskAreas).where(eq(riskAreas.id, id));
    return riskArea || undefined;
  }

  async createRiskArea(riskArea: InsertRiskArea): Promise<RiskArea> {
    const [newRiskArea] = await db.insert(riskAreas).values([riskArea]).returning();
    return newRiskArea;
  }

  async updateRiskArea(id: string, riskArea: Partial<InsertRiskArea>): Promise<RiskArea | undefined> {
    const [updatedRiskArea] = await db.update(riskAreas).set(riskArea).where(eq(riskAreas.id, id)).returning();
    return updatedRiskArea || undefined;
  }

  async getNotifications(userId?: string, limit = 50): Promise<Notification[]> {
    let query = db.select().from(notifications);
    
    if (userId) {
      query = query.where(eq(notifications.userId, userId));
    }
    
    return await query.orderBy(desc(notifications.createdAt)).limit(limit);
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values([notification]).returning();
    return newNotification;
  }

  async updateNotification(id: string, notification: Partial<InsertNotification>): Promise<Notification | undefined> {
    const [updatedNotification] = await db.update(notifications).set(notification).where(eq(notifications.id, id)).returning();
    return updatedNotification || undefined;
  }

  async getHealthDiaryEntries(userId: string): Promise<HealthDiaryEntry[]> {
    return await db.select().from(healthDiaryEntries)
      .where(eq(healthDiaryEntries.userId, userId))
      .orderBy(desc(healthDiaryEntries.date));
  }

  async createHealthDiaryEntry(entry: InsertHealthDiaryEntry): Promise<HealthDiaryEntry> {
    const [newEntry] = await db.insert(healthDiaryEntries).values([entry]).returning();
    return newEntry;
  }

  async getWeatherData(location: string): Promise<WeatherData[]> {
    return await db.select().from(weatherData)
      .where(like(weatherData.location, `%${location}%`))
      .orderBy(desc(weatherData.timestamp))
      .limit(24);
  }

  async createWeatherData(data: InsertWeatherData): Promise<WeatherData> {
    const [newData] = await db.insert(weatherData).values([data]).returning();
    return newData;
  }

  async getDashboardStats(): Promise<{
    activeCases: number;
    highRiskAreas: number;
    waterQualityIndex: number;
    hospitalsAvailable: number;
  }> {
    const [activeCasesResult] = await db.select({ count: sql<number>`count(*)` })
      .from(diseaseCases)
      .where(eq(diseaseCases.status, 'confirmed'));

    const [highRiskAreasResult] = await db.select({ count: sql<number>`count(*)` })
      .from(riskAreas)
      .where(and(eq(riskAreas.isActive, true), eq(riskAreas.riskLevel, 'high')));

    const [hospitalsResult] = await db.select({ count: sql<number>`count(*)` })
      .from(hospitals)
      .where(eq(hospitals.isActive, true));

    // Calculate average water quality index from recent data
    const [waterQualityResult] = await db.select({ 
      avgPh: sql<number>`avg(${waterQualityData.ph})`,
      avgTurbidity: sql<number>`avg(${waterQualityData.turbidity})`,
      avgDO: sql<number>`avg(${waterQualityData.dissolvedOxygen})`
    })
    .from(waterQualityData)
    .where(gte(waterQualityData.timestamp, sql`now() - interval '24 hours'`));

    // Simple water quality index calculation (0-100)
    const ph = waterQualityResult?.avgPh || 7;
    const turbidity = waterQualityResult?.avgTurbidity || 5;
    const dissolvedOxygen = waterQualityResult?.avgDO || 8;
    
    const phScore = Math.max(0, 100 - Math.abs(ph - 7) * 20);
    const turbidityScore = Math.max(0, 100 - turbidity * 10);
    const doScore = Math.min(100, dissolvedOxygen * 10);
    
    const waterQualityIndex = Math.round((phScore + turbidityScore + doScore) / 3);

    return {
      activeCases: activeCasesResult?.count || 0,
      highRiskAreas: highRiskAreasResult?.count || 0,
      waterQualityIndex,
      hospitalsAvailable: hospitalsResult?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
