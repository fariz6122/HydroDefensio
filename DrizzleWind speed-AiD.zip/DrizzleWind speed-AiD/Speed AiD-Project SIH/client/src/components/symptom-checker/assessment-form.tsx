import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle, AlertTriangle, Clock, MapPin } from "lucide-react";
import type { SymptomAssessment } from "@/lib/types";

export default function AssessmentForm() {
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [severity, setSeverity] = useState([5]);
  const [duration, setDuration] = useState("recent");
  const [age, setAge] = useState("30");
  const [location, setLocation] = useState("");
  const [assessment, setAssessment] = useState<SymptomAssessment | null>(null);

  const { toast } = useToast();

  const availableSymptoms = [
    { id: 'diarrhea', label: 'Diarrhea', category: 'gastrointestinal' },
    { id: 'vomiting', label: 'Vomiting', category: 'gastrointestinal' },
    { id: 'nausea', label: 'Nausea', category: 'gastrointestinal' },
    { id: 'stomach_cramps', label: 'Stomach cramps', category: 'gastrointestinal' },
    { id: 'fever', label: 'Fever', category: 'systemic' },
    { id: 'headache', label: 'Headache', category: 'systemic' },
    { id: 'weakness', label: 'Weakness/Fatigue', category: 'systemic' },
    { id: 'dehydration', label: 'Dehydration', category: 'systemic' },
    { id: 'jaundice', label: 'Jaundice (yellowing of skin/eyes)', category: 'liver' },
    { id: 'loss_of_appetite', label: 'Loss of appetite', category: 'gastrointestinal' },
    { id: 'bloody_diarrhea', label: 'Blood in stool', category: 'gastrointestinal' },
    { id: 'gas', label: 'Excessive gas', category: 'gastrointestinal' },
  ];

  const assessmentMutation = useMutation({
    mutationFn: async (data: {
      symptoms: string[];
      severity: number;
      duration: string;
      age: number;
      location: string;
    }) => {
      const response = await apiRequest("POST", "/api/symptom-checker/assess", data);
      return response.json();
    },
    onSuccess: (data: SymptomAssessment) => {
      setAssessment(data);
    },
    onError: () => {
      toast({
        title: "Assessment Failed",
        description: "Unable to process your symptoms. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSymptomChange = (symptomId: string, checked: boolean) => {
    if (checked) {
      setSymptoms(prev => [...prev, symptomId]);
    } else {
      setSymptoms(prev => prev.filter(s => s !== symptomId));
    }
  };

  const handleSubmit = () => {
    if (symptoms.length === 0) {
      toast({
        title: "Select Symptoms",
        description: "Please select at least one symptom to continue.",
        variant: "destructive",
      });
      return;
    }

    assessmentMutation.mutate({
      symptoms,
      severity: severity[0],
      duration,
      age: parseInt(age),
      location: location || "Northeast India",
    });
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical': return 'border-destructive bg-destructive/10 text-destructive';
      case 'high': return 'border-accent bg-accent/10 text-accent';
      case 'medium': return 'border-chart-4 bg-chart-4/10 text-foreground';
      case 'low': return 'border-secondary bg-secondary/10 text-secondary';
      default: return 'border-border bg-muted text-muted-foreground';
    }
  };

  const getUrgencyIcon = (urgency: string) => {
    switch (urgency) {
      case 'immediate': return <AlertTriangle className="w-5 h-5 text-destructive" />;
      case 'consult': return <Clock className="w-5 h-5 text-accent" />;
      case 'monitor': return <CheckCircle className="w-5 h-5 text-primary" />;
      default: return <CheckCircle className="w-5 h-5 text-secondary" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card data-testid="assessment-form">
        <CardHeader>
          <CardTitle>Symptom Assessment</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                type="number"
                placeholder="Enter your age"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                data-testid="age-input"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                placeholder="e.g., Guwahati, Assam"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                data-testid="location-input"
              />
            </div>
          </div>

          {/* Symptom Duration */}
          <div className="space-y-2">
            <Label>How long have you been experiencing symptoms?</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger data-testid="duration-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Less than 24 hours</SelectItem>
                <SelectItem value="1-3days">1-3 days</SelectItem>
                <SelectItem value="3-7days">3-7 days</SelectItem>
                <SelectItem value="1-2weeks">1-2 weeks</SelectItem>
                <SelectItem value="longer">More than 2 weeks</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Severity Scale */}
          <div className="space-y-3">
            <Label>Overall symptom severity (1 = mild, 10 = severe)</Label>
            <div className="px-3">
              <Slider
                value={severity}
                onValueChange={setSeverity}
                max={10}
                min={1}
                step={1}
                className="w-full"
                data-testid="severity-slider"
              />
              <div className="flex justify-between text-sm text-muted-foreground mt-1">
                <span>Mild (1)</span>
                <span className="font-medium">Current: {severity[0]}</span>
                <span>Severe (10)</span>
              </div>
            </div>
          </div>

          {/* Symptoms Selection */}
          <div className="space-y-3">
            <Label>Select all symptoms you are experiencing:</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {availableSymptoms.map((symptom) => (
                <div key={symptom.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={symptom.id}
                    checked={symptoms.includes(symptom.id)}
                    onCheckedChange={(checked) => handleSymptomChange(symptom.id, checked as boolean)}
                    data-testid={`symptom-${symptom.id}`}
                  />
                  <Label htmlFor={symptom.id} className="text-sm">
                    {symptom.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Submit Button */}
          <Button 
            onClick={handleSubmit}
            disabled={assessmentMutation.isPending || symptoms.length === 0}
            className="w-full"
            data-testid="submit-assessment"
          >
            {assessmentMutation.isPending ? "Analyzing..." : "Analyze Symptoms"}
          </Button>
        </CardContent>
      </Card>

      {/* Assessment Results */}
      {assessment && (
        <Card className={`border-2 ${getRiskColor(assessment.riskLevel)}`} data-testid="assessment-results">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              {getUrgencyIcon(assessment.urgency)}
              <span>Assessment Results</span>
              <Badge className={getRiskColor(assessment.riskLevel)}>
                {assessment.riskLevel.toUpperCase()} RISK
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Risk Score */}
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-3xl font-bold text-foreground">
                {Math.round(assessment.score)}%
              </div>
              <div className="text-sm text-muted-foreground">Risk Score</div>
            </div>

            {/* Possible Diseases */}
            {assessment.possibleDiseases.length > 0 && (
              <div>
                <h3 className="font-medium text-foreground mb-2">Possible Conditions:</h3>
                <div className="flex flex-wrap gap-2">
                  {assessment.possibleDiseases.map((disease, index) => (
                    <Badge key={index} variant="outline" className="capitalize">
                      {disease}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Recommendations */}
            <div>
              <h3 className="font-medium text-foreground mb-2">Recommendations:</h3>
              <ul className="space-y-1">
                {assessment.recommendations.map((rec, index) => (
                  <li key={index} className="text-sm text-muted-foreground flex items-start space-x-2">
                    <span className="text-primary mt-1">•</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Urgency Alert */}
            {assessment.urgency === 'immediate' && (
              <Alert className="border-destructive bg-destructive/10">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Seek immediate medical attention!</strong> Your symptoms indicate a potentially serious condition that requires urgent care.
                </AlertDescription>
              </Alert>
            )}

            {/* Next Steps */}
            <div className="border-t border-border pt-4">
              <h4 className="font-medium text-foreground mb-2">Next Steps:</h4>
              <div className="space-y-2">
                {assessment.urgency === 'immediate' && (
                  <Button variant="destructive" className="w-full">
                    <MapPin className="w-4 h-4 mr-2" />
                    Find Nearest Hospital
                  </Button>
                )}
                {assessment.urgency === 'consult' && (
                  <Button variant="outline" className="w-full">
                    <Clock className="w-4 h-4 mr-2" />
                    Schedule Appointment
                  </Button>
                )}
                <Button variant="outline" className="w-full">
                  Save to Health Diary
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
