import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { AlertTriangle, Send } from "lucide-react";

interface EmergencyAlertDialogProps {
  onClose: () => void;
}

export function EmergencyAlertDialog({ onClose }: EmergencyAlertDialogProps) {
  const [message, setMessage] = useState("");
  const [priority, setPriority] = useState("critical");
  const [targetArea, setTargetArea] = useState("all");
  const [channels, setChannels] = useState({
    sms: true,
    email: true,
    whatsapp: true,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sendAlertMutation = useMutation({
    mutationFn: async (data: {
      message: string;
      priority: string;
      targetArea: string;
      channels: string[];
    }) => {
      return apiRequest("POST", "/api/notifications/emergency", data);
    },
    onSuccess: () => {
      toast({
        title: "Emergency Alert Sent",
        description: "The emergency alert has been broadcast to all selected channels.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      onClose();
    },
    onError: () => {
      toast({
        title: "Failed to Send Alert",
        description: "There was an error sending the emergency alert. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!message.trim()) {
      toast({
        title: "Message Required",
        description: "Please enter an emergency message before sending.",
        variant: "destructive",
      });
      return;
    }

    const selectedChannels = Object.entries(channels)
      .filter(([_, enabled]) => enabled)
      .map(([channel, _]) => channel);

    if (selectedChannels.length === 0) {
      toast({
        title: "Select Channels",
        description: "Please select at least one communication channel.",
        variant: "destructive",
      });
      return;
    }

    sendAlertMutation.mutate({
      message,
      priority,
      targetArea,
      channels: selectedChannels,
    });
  };

  return (
    <div className="space-y-6" data-testid="emergency-alert-dialog">
      {/* Alert Header */}
      <div className="flex items-center space-x-2 text-destructive">
        <AlertTriangle className="w-5 h-5" />
        <span className="font-medium">Emergency Alert System</span>
      </div>

      {/* Message Input */}
      <div className="space-y-2">
        <Label htmlFor="alert-message">Emergency Message</Label>
        <Textarea
          id="alert-message"
          placeholder="Enter emergency alert message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={4}
          data-testid="alert-message-input"
        />
        <p className="text-xs text-muted-foreground">
          This message will be sent to all users in the selected target area.
        </p>
      </div>

      {/* Priority Level */}
      <div className="space-y-2">
        <Label htmlFor="priority-select">Priority Level</Label>
        <Select value={priority} onValueChange={setPriority}>
          <SelectTrigger data-testid="priority-select">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="critical">Critical - Immediate Danger</SelectItem>
            <SelectItem value="high">High - Urgent Action Required</SelectItem>
            <SelectItem value="medium">Medium - Important Notice</SelectItem>
            <SelectItem value="low">Low - General Information</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Target Area */}
      <div className="space-y-2">
        <Label htmlFor="target-area">Target Area</Label>
        <Select value={targetArea} onValueChange={setTargetArea}>
          <SelectTrigger data-testid="target-area-select">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Users</SelectItem>
            <SelectItem value="guwahati">Guwahati Region</SelectItem>
            <SelectItem value="silchar">Silchar Region</SelectItem>
            <SelectItem value="itanagar">Itanagar Region</SelectItem>
            <SelectItem value="imphal">Imphal Region</SelectItem>
            <SelectItem value="aizawl">Aizawl Region</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Communication Channels */}
      <div className="space-y-3">
        <Label>Communication Channels</Label>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="sms-channel"
              checked={channels.sms}
              onCheckedChange={(checked) => 
                setChannels(prev => ({ ...prev, sms: checked as boolean }))
              }
              data-testid="sms-channel-checkbox"
            />
            <Label htmlFor="sms-channel" className="text-sm">
              SMS (Twilio) - Immediate mobile alerts
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="email-channel"
              checked={channels.email}
              onCheckedChange={(checked) => 
                setChannels(prev => ({ ...prev, email: checked as boolean }))
              }
              data-testid="email-channel-checkbox"
            />
            <Label htmlFor="email-channel" className="text-sm">
              Email (SendGrid) - Detailed information
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="whatsapp-channel"
              checked={channels.whatsapp}
              onCheckedChange={(checked) => 
                setChannels(prev => ({ ...prev, whatsapp: checked as boolean }))
              }
              data-testid="whatsapp-channel-checkbox"
            />
            <Label htmlFor="whatsapp-channel" className="text-sm">
              WhatsApp Business - Community messaging
            </Label>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end space-x-3">
        <Button variant="outline" onClick={onClose} data-testid="cancel-alert-button">
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          disabled={sendAlertMutation.isPending}
          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          data-testid="send-alert-button"
        >
          {sendAlertMutation.isPending ? (
            "Sending..."
          ) : (
            <>
              <Send className="w-4 h-4 mr-2" />
              Send Emergency Alert
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
