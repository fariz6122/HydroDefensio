import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { AlertTriangle, Search, Plus, Eye, MapPin, Calendar, Users, TrendingUp, MessageSquare } from "lucide-react";
import type { DiseaseCase } from "@/lib/types";

interface OutbreakManagementProps {
  cases: DiseaseCase[];
}

export default function OutbreakManagement({ cases }: OutbreakManagementProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [severityFilter, setSeverityFilter] = useState("all");
  const [isAlertDialogOpen, setIsAlertDialogOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<DiseaseCase | null>(null);
  const { toast } = useToast();

  const sendAlertMutation = useMutation({
    mutationFn: async (alertData: { 
      title: string; 
      message: string; 
      priority: string; 
      channels: string[];
      targetArea: string;
    }) => {
      return apiRequest("POST", "/api/notifications", alertData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      setIsAlertDialogOpen(false);
      toast({
        title: "Alert Sent",
        description: "Emergency alert has been dispatched to the affected areas.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send alert. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateCaseStatusMutation = useMutation({
    mutationFn: async ({ caseId, status }: { caseId: string; status: string }) => {
      return apiRequest("PUT", `/api/disease-cases/${caseId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/disease-cases"] });
      toast({
        title: "Case Updated",
        description: "Disease case status has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update case status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const filteredCases = cases.filter(diseaseCase => {
    const matchesSearch = diseaseCase.location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         diseaseCase.diseaseId?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || diseaseCase.status === statusFilter;
    const matchesSeverity = severityFilter === "all" || diseaseCase.severity === severityFilter;
    return matchesSearch && matchesStatus && matchesSeverity;
  });

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'critical': return 'bg-destructive text-destructive-foreground';
      case 'high': return 'bg-orange-500 text-white';
      case 'medium': return 'bg-yellow-500 text-black';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-secondary text-secondary-foreground';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'confirmed': return 'bg-destructive text-destructive-foreground';
      case 'suspected': return 'bg-orange-500 text-white';
      case 'under_investigation': return 'bg-yellow-500 text-black';
      case 'resolved': return 'bg-green-500 text-white';
      default: return 'bg-secondary text-secondary-foreground';
    }
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString('en-IN', { 
      day: '2-digit', 
      month: 'short', 
      year: 'numeric' 
    });
  };

  const handleSendAlert = (formData: FormData) => {
    const alertData = {
      title: formData.get("title") as string,
      message: formData.get("message") as string,
      priority: formData.get("priority") as string,
      channels: ["sms", "email", "whatsapp"],
      targetArea: formData.get("targetArea") as string,
    };
    sendAlertMutation.mutate(alertData);
  };

  // Calculate outbreak statistics
  const outbreakStats = {
    active: cases.filter(c => c.status === 'confirmed' || c.status === 'suspected').length,
    critical: cases.filter(c => c.severity === 'critical').length,
    resolved: cases.filter(c => c.status === 'resolved').length,
    underInvestigation: cases.filter(c => c.status === 'under_investigation').length,
  };

  return (
    <Card data-testid="outbreak-management">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-destructive" />
            <CardTitle>Outbreak Management</CardTitle>
          </div>
          <Dialog open={isAlertDialogOpen} onOpenChange={setIsAlertDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2 bg-destructive hover:bg-destructive/90" data-testid="send-alert-button">
                <MessageSquare className="w-4 h-4" />
                <span>Send Emergency Alert</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Send Emergency Health Alert</DialogTitle>
              </DialogHeader>
              <form onSubmit={(e) => {
                e.preventDefault();
                handleSendAlert(new FormData(e.currentTarget));
              }} className="space-y-4">
                <div>
                  <Label htmlFor="title">Alert Title</Label>
                  <Input 
                    id="title" 
                    name="title" 
                    placeholder="e.g., Cholera Outbreak in Guwahati"
                    required 
                    data-testid="alert-title-input" 
                  />
                </div>
                <div>
                  <Label htmlFor="message">Alert Message</Label>
                  <Textarea 
                    id="message" 
                    name="message" 
                    placeholder="Detailed information about the health emergency..."
                    rows={4}
                    required 
                    data-testid="alert-message-input" 
                  />
                </div>
                <div>
                  <Label htmlFor="priority">Priority Level</Label>
                  <Select name="priority" required>
                    <SelectTrigger data-testid="priority-select">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="targetArea">Target Area</Label>
                  <Input 
                    id="targetArea" 
                    name="targetArea" 
                    placeholder="e.g., Guwahati, Assam or All Northeast States"
                    required 
                    data-testid="target-area-input" 
                  />
                </div>
                <Button type="submit" className="w-full bg-destructive hover:bg-destructive/90" disabled={sendAlertMutation.isPending}>
                  {sendAlertMutation.isPending ? "Sending Alert..." : "Send Emergency Alert"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Outbreak Statistics */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <Card className="border-destructive bg-destructive/5">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Cases</p>
                    <p className="text-2xl font-bold text-destructive">{outbreakStats.active}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-destructive" />
                </div>
              </CardContent>
            </Card>
            <Card className="border-orange-200 bg-orange-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Critical</p>
                    <p className="text-2xl font-bold text-orange-600">{outbreakStats.critical}</p>
                  </div>
                  <AlertTriangle className="w-8 h-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="p-4">
                <div>
                  <p className="text-sm text-muted-foreground">Investigating</p>
                  <p className="text-2xl font-bold text-yellow-600">{outbreakStats.underInvestigation}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4">
                <div>
                  <p className="text-sm text-muted-foreground">Resolved</p>
                  <p className="text-2xl font-bold text-green-600">{outbreakStats.resolved}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by location or disease..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="search-cases"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48" data-testid="filter-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="confirmed">Confirmed</SelectItem>
                <SelectItem value="suspected">Suspected</SelectItem>
                <SelectItem value="under_investigation">Under Investigation</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
              </SelectContent>
            </Select>
            <Select value={severityFilter} onValueChange={setSeverityFilter}>
              <SelectTrigger className="w-full sm:w-48" data-testid="filter-severity">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severities</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Cases Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Disease & Location</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Reported Date</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCases.map((diseaseCase) => (
                  <TableRow key={diseaseCase.id} data-testid={`case-row-${diseaseCase.id}`}>
                    <TableCell className="font-medium">
                      <div>
                        <p className="text-sm font-medium text-foreground capitalize">
                          {diseaseCase.diseaseId || "Unknown Disease"}
                        </p>
                        <div className="flex items-center space-x-1 mt-1">
                          <MapPin className="w-3 h-3 text-muted-foreground" />
                          <p className="text-xs text-muted-foreground">{diseaseCase.location}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getSeverityColor(diseaseCase.severity || "unknown")}>
                        {diseaseCase.severity || "Unknown"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(diseaseCase.status || "unknown")}>
                        {diseaseCase.status?.replace('_', ' ') || "Unknown"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-3 h-3 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          {formatDate(diseaseCase.reportedDate)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground capitalize">
                        {diseaseCase.source || "Unknown"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedCase(diseaseCase)}
                          data-testid={`view-case-${diseaseCase.id}`}
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                        <Select
                          value={diseaseCase.status || ""}
                          onValueChange={(status) => 
                            updateCaseStatusMutation.mutate({ 
                              caseId: diseaseCase.id, 
                              status 
                            })
                          }
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="suspected">Suspected</SelectItem>
                            <SelectItem value="confirmed">Confirmed</SelectItem>
                            <SelectItem value="under_investigation">Investigating</SelectItem>
                            <SelectItem value="resolved">Resolved</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredCases.length === 0 && (
            <div className="text-center py-8">
              <AlertTriangle className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 text-sm font-semibold text-foreground">No cases found</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {searchTerm ? "Try adjusting your search criteria." : "No disease cases match the current filters."}
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}