import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, Activity, Database, Clock, Zap } from "lucide-react";

interface AdminMetricsProps {
  stats: {
    totalUsers: number;
    activeCases: number;
    totalHospitals: number;
    alertsSent: number;
    criticalAlerts: number;
    systemUptime: string;
    responseTime: string;
    dataProcessed: string;
  };
}

export default function AdminMetrics({ stats }: AdminMetricsProps) {
  const metrics = [
    {
      title: "Total Users",
      value: stats.totalUsers.toLocaleString(),
      change: "+12%",
      trend: "up",
      icon: Activity,
      color: "primary",
    },
    {
      title: "Active Disease Cases",
      value: stats.activeCases.toLocaleString(),
      change: "+8%",
      trend: "up",
      icon: TrendingUp,
      color: "destructive",
    },
    {
      title: "Healthcare Facilities",
      value: stats.totalHospitals.toLocaleString(),
      change: "+2",
      trend: "up",
      icon: Activity,
      color: "secondary",
    },
    {
      title: "Alerts Sent Today",
      value: stats.alertsSent.toLocaleString(),
      change: "+24%",
      trend: "up",
      icon: Zap,
      color: "accent",
    },
  ];

  const systemMetrics = [
    {
      title: "System Uptime",
      value: stats.systemUptime,
      icon: Clock,
      progress: 99.9,
    },
    {
      title: "Avg Response Time",
      value: stats.responseTime,
      icon: Zap,
      progress: 85,
    },
    {
      title: "Data Processed",
      value: stats.dataProcessed,
      icon: Database,
      progress: 67,
    },
  ];

  return (
    <div className="space-y-6" data-testid="admin-metrics">
      {/* Primary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index} className="hover:shadow-sm transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {metric.title}
                    </p>
                    <p className="text-2xl font-bold text-foreground">
                      {metric.value}
                    </p>
                  </div>
                  <div className={`w-12 h-12 bg-${metric.color}/10 rounded-lg flex items-center justify-center`}>
                    <Icon className={`w-6 h-6 text-${metric.color}`} />
                  </div>
                </div>
                <div className="flex items-center mt-4">
                  {metric.trend === "up" ? (
                    <TrendingUp className="w-4 h-4 text-secondary mr-1" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-destructive mr-1" />
                  )}
                  <span className={`text-sm font-medium ${
                    metric.trend === "up" ? "text-secondary" : "text-destructive"
                  }`}>
                    {metric.change}
                  </span>
                  <span className="text-sm text-muted-foreground ml-2">
                    from last month
                  </span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* System Performance */}
      <Card>
        <CardHeader>
          <CardTitle>System Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {systemMetrics.map((metric, index) => {
              const Icon = metric.icon;
              return (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Icon className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-foreground">
                        {metric.title}
                      </span>
                    </div>
                    <span className="text-sm font-bold text-foreground">
                      {metric.value}
                    </span>
                  </div>
                  <Progress value={metric.progress} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0%</span>
                    <span>100%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Critical Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-destructive bg-destructive/5">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-destructive">Critical Alerts</CardTitle>
              <Badge className="bg-destructive text-destructive-foreground">
                {stats.criticalAlerts} Active
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-destructive/10 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-foreground">Cholera Outbreak - Guwahati</p>
                  <p className="text-xs text-muted-foreground">High priority • 2 hours ago</p>
                </div>
                <Badge variant="destructive">Active</Badge>
              </div>
              <div className="flex items-center justify-between p-3 bg-destructive/10 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-foreground">Water Contamination - Silchar</p>
                  <p className="text-xs text-muted-foreground">Critical • 4 hours ago</p>
                </div>
                <Badge variant="destructive">Active</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Communication Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">SMS Service (Twilio)</span>
                <Badge className="bg-secondary text-secondary-foreground">Operational</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Email Service (SendGrid)</span>
                <Badge className="bg-secondary text-secondary-foreground">Operational</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">WhatsApp Business API</span>
                <Badge className="bg-secondary text-secondary-foreground">Operational</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Weather API</span>
                <Badge className="bg-secondary text-secondary-foreground">Operational</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
