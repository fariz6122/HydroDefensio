import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import type { WaterQualityData } from "@/lib/types";

export default function WaterQualityMonitor() {
  const { data: waterData, isLoading, refetch } = useQuery<WaterQualityData[]>({
    queryKey: ["/api/water-quality"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-60 w-full" />
        </CardContent>
      </Card>
    );
  }

  const latestData = waterData?.[0];
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-secondary text-secondary-foreground';
      case 'maintenance': return 'bg-accent text-accent-foreground';
      case 'offline': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getProgressColor = (value: number, min: number, max: number) => {
    const percentage = ((value - min) / (max - min)) * 100;
    if (percentage < 30 || percentage > 80) return 'bg-destructive';
    if (percentage < 50 || percentage > 70) return 'bg-accent';
    return 'bg-secondary';
  };

  return (
    <Card data-testid="water-quality-monitor">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Water Quality Monitoring</CardTitle>
          <div className="flex items-center space-x-2">
            <Badge className="bg-secondary text-secondary-foreground">
              Live Data
            </Badge>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => refetch()}
              data-testid="refresh-water-data"
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {latestData ? (
          <div className="space-y-6">
            {/* Water Quality Metrics */}
            <div className="space-y-4" data-testid="water-quality-metrics">
              {/* pH Level */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">pH Level</span>
                  <span className="text-foreground font-medium">
                    {parseFloat(latestData.ph || "7.2").toFixed(1)}
                  </span>
                </div>
                <Progress 
                  value={((parseFloat(latestData.ph || "7.2") - 6) / 3) * 100} 
                  className="h-2"
                />
              </div>
              
              {/* Turbidity */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Turbidity (NTU)</span>
                  <span className="text-foreground font-medium">
                    {parseFloat(latestData.turbidity || "3.8").toFixed(1)}
                  </span>
                </div>
                <Progress 
                  value={(parseFloat(latestData.turbidity || "3.8") / 10) * 100} 
                  className="h-2"
                />
              </div>
              
              {/* Dissolved Oxygen */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Dissolved Oxygen (mg/L)</span>
                  <span className="text-foreground font-medium">
                    {parseFloat(latestData.dissolvedOxygen || "8.5").toFixed(1)}
                  </span>
                </div>
                <Progress 
                  value={(parseFloat(latestData.dissolvedOxygen || "8.5") / 15) * 100} 
                  className="h-2"
                />
              </div>
              
              {/* E. coli Count */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">E. coli Count (CFU/100ml)</span>
                  <span className="text-foreground font-medium">
                    {latestData.ecoliCount || 0}
                  </span>
                </div>
                <Progress 
                  value={Math.min((latestData.ecoliCount || 0) / 100 * 100, 100)} 
                  className="h-2"
                />
              </div>
            </div>
            
            {/* Sensor Locations */}
            <div>
              <h4 className="text-sm font-medium text-foreground mb-3">Active Sensors</h4>
              <div className="space-y-2" data-testid="sensor-locations">
                {waterData?.slice(0, 3).map((sensor, index) => (
                  <div key={sensor.id} className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{sensor.location}</span>
                    <Badge 
                      className={getStatusColor(sensor.status)}
                      data-testid={`sensor-status-${index}`}
                    >
                      {sensor.status}
                    </Badge>
                  </div>
                )) || (
                  <div className="text-sm text-muted-foreground">
                    No sensor data available
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No water quality data available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
