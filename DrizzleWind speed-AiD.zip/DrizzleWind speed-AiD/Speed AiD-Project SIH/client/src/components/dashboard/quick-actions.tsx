import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmergencyAlertDialog } from "@/components/communication/emergency-alert-dialog";
import { Stethoscope, Bell, Calendar, FileText } from "lucide-react";
import { Link } from "wouter";

export default function QuickActions() {
  const [showEmergencyDialog, setShowEmergencyDialog] = useState(false);

  const actions = [
    {
      name: "Symptom Checker",
      description: "Check symptoms for waterborne diseases",
      icon: Stethoscope,
      href: "/symptom-checker",
      color: "primary",
    },
    {
      name: "Send Alert",
      description: "Broadcast emergency notification",
      icon: Bell,
      action: () => setShowEmergencyDialog(true),
      color: "destructive",
    },
    {
      name: "Book Appointment",
      description: "Schedule healthcare visit",
      icon: Calendar,
      href: "/appointments",
      color: "secondary",
    },
    {
      name: "View Reports",
      description: "Access health reports & analytics",
      icon: FileText,
      href: "/disease-trends",
      color: "accent",
    },
  ];

  return (
    <>
      <Card data-testid="quick-actions">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {actions.map((action) => {
              const Icon = action.icon;
              const content = (
                <div className="flex flex-col items-center p-4 bg-muted hover:bg-muted/80 rounded-lg transition-colors cursor-pointer">
                  <div className={`w-12 h-12 bg-${action.color} rounded-lg flex items-center justify-center mb-3`}>
                    <Icon className={`w-6 h-6 text-${action.color}-foreground`} />
                  </div>
                  <span className="text-sm font-medium text-foreground text-center">
                    {action.name}
                  </span>
                  <span className="text-xs text-muted-foreground text-center mt-1">
                    {action.description}
                  </span>
                </div>
              );

              if (action.href) {
                return (
                  <Link key={action.name} href={action.href}>
                    <div data-testid={`quick-action-${action.name.toLowerCase().replace(' ', '-')}`}>
                      {content}
                    </div>
                  </Link>
                );
              } else {
                return (
                  <Button
                    key={action.name}
                    variant="ghost"
                    className="h-auto p-0"
                    onClick={action.action}
                    data-testid={`quick-action-${action.name.toLowerCase().replace(' ', '-')}`}
                  >
                    {content}
                  </Button>
                );
              }
            })}
          </div>
        </CardContent>
      </Card>

      <Dialog open={showEmergencyDialog} onOpenChange={setShowEmergencyDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send Emergency Alert</DialogTitle>
          </DialogHeader>
          <EmergencyAlertDialog onClose={() => setShowEmergencyDialog(false)} />
        </DialogContent>
      </Dialog>
    </>
  );
}
