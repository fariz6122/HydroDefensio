import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, Droplet, Info } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { Notification } from "@/lib/types";

export default function AlertsFeed() {
  const { data: notifications, isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'emergency':
      case 'alert':
        return AlertTriangle;
      case 'info':
        return Info;
      default:
        return Droplet;
    }
  };

  const getAlertColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'bg-destructive/10 border-destructive/20 text-destructive';
      case 'high':
        return 'bg-accent/10 border-accent/20 text-accent';
      case 'medium':
        return 'bg-primary/10 border-primary/20 text-primary';
      default:
        return 'bg-muted border-border text-muted-foreground';
    }
  };

  const getChannelBadges = (channels: string[]) => {
    const channelMap = {
      sms: 'SMS',
      email: 'Email',
      whatsapp: 'WhatsApp',
      push: 'Push'
    };

    return channels.map(channel => channelMap[channel as keyof typeof channelMap] || channel);
  };

  return (
    <Card data-testid="alerts-feed">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Recent Alerts</CardTitle>
          <Button variant="link" className="text-primary hover:text-primary/80" data-testid="view-all-alerts">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {notifications?.slice(0, 5).map((notification) => {
            const Icon = getAlertIcon(notification.type);
            return (
              <div
                key={notification.id}
                className={`flex items-start space-x-3 p-3 rounded-lg border ${getAlertColor(notification.priority)}`}
                data-testid={`alert-item-${notification.id}`}
              >
                <div className="flex-shrink-0">
                  <Icon className="w-5 h-5 mt-0.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">
                    {notification.title}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {notification.message}
                  </p>
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })} • 
                      {getChannelBadges(notification.channels).join(', ')} Sent
                    </p>
                    <Badge 
                      variant="outline" 
                      className="text-xs"
                      data-testid={`alert-status-${notification.id}`}
                    >
                      {notification.status}
                    </Badge>
                  </div>
                </div>
              </div>
            );
          }) || (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No recent alerts</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
