import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Maximize, MapPin } from "lucide-react";
import type { DiseaseCase, RiskArea } from "@/lib/types";

export default function DiseaseMap() {
  const { data: diseaseCases, isLoading: casesLoading } = useQuery<DiseaseCase[]>({
    queryKey: ["/api/disease-cases"],
  });

  const { data: riskAreas, isLoading: areasLoading } = useQuery<RiskArea[]>({
    queryKey: ["/api/risk-areas"],
  });

  if (casesLoading || areasLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-80 w-full" />
        </CardContent>
      </Card>
    );
  }

  // Simulate map markers based on disease cases
  const mapMarkers = diseaseCases?.slice(0, 10).map((caseItem, index) => ({
    id: caseItem.id,
    latitude: parseFloat(caseItem.latitude || "26.1445"),
    longitude: parseFloat(caseItem.longitude || "91.7362"),
    severity: caseItem.severity,
    location: caseItem.location,
    status: caseItem.status,
  })) || [];

  const getRiskColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'critical': return 'marker-critical';
      case 'high': return 'marker-high';
      case 'medium': return 'marker-medium';
      default: return 'marker-low';
    }
  };

  return (
    <Card data-testid="disease-map-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Disease Outbreak Map</CardTitle>
          <div className="flex space-x-2">
            <Badge variant="secondary" className="bg-secondary text-secondary-foreground">
              Live
            </Badge>
            <Button variant="ghost" size="sm" data-testid="maximize-map-button">
              <Maximize className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80 bg-muted rounded-lg relative overflow-hidden" data-testid="map-container">
          {/* Simulated map background */}
          <img 
            src="https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&h=600" 
            alt="Northeast India map"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20"></div>
          
          {/* Disease markers */}
          {mapMarkers.map((marker, index) => (
            <div
              key={marker.id}
              className={`absolute w-4 h-4 rounded-full cursor-pointer transform -translate-x-1/2 -translate-y-1/2 ${getRiskColor(marker.severity)}`}
              style={{
                top: `${25 + (index % 3) * 25}%`,
                left: `${30 + (index % 4) * 15}%`,
              }}
              title={`${marker.location} - ${marker.severity} risk - ${marker.status}`}
              data-testid={`disease-marker-${index}`}
            />
          ))}
          
          {/* Legend */}
          <div className="absolute bottom-4 left-4 bg-card/90 backdrop-blur-sm rounded-lg p-3 space-y-2" data-testid="map-legend">
            <div className="flex items-center space-x-2 text-xs">
              <div className="w-3 h-3 bg-destructive rounded-full"></div>
              <span className="text-foreground">Critical Risk</span>
            </div>
            <div className="flex items-center space-x-2 text-xs">
              <div className="w-3 h-3 bg-accent rounded-full"></div>
              <span className="text-foreground">High Risk</span>
            </div>
            <div className="flex items-center space-x-2 text-xs">
              <div className="w-3 h-3 bg-chart-4 rounded-full"></div>
              <span className="text-foreground">Medium Risk</span>
            </div>
            <div className="flex items-center space-x-2 text-xs">
              <div className="w-3 h-3 bg-secondary rounded-full"></div>
              <span className="text-foreground">Low Risk</span>
            </div>
          </div>

          {/* Location info overlay */}
          <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm rounded-lg p-3" data-testid="location-info">
            <div className="flex items-center space-x-2 text-sm">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-foreground font-medium">Northeast India</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {mapMarkers.length} active monitoring points
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
