import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useState } from "react";
import type { DiseaseCase } from "@/lib/types";

export default function TrendChart() {
  const [timeRange, setTimeRange] = useState("30");
  
  const { data: diseaseCases, isLoading } = useQuery<DiseaseCase[]>({
    queryKey: ["/api/disease-cases"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-80 w-full" />
        </CardContent>
      </Card>
    );
  }

  // Process disease data for chart
  const diseases = ['Cholera', 'Typhoid', 'Hepatitis A', 'E. coli', 'Giardia'];
  const chartData = diseases.map(disease => ({
    name: disease,
    cases: Math.floor(Math.random() * 50) + 10, // Mock data
    color: getChartColor(disease),
  }));

  function getChartColor(disease: string) {
    const colors = {
      'Cholera': 'hsl(var(--chart-1))',
      'Typhoid': 'hsl(var(--chart-2))',
      'Hepatitis A': 'hsl(var(--chart-3))',
      'E. coli': 'hsl(var(--chart-4))',
      'Giardia': 'hsl(var(--chart-5))',
    };
    return colors[disease as keyof typeof colors] || 'hsl(var(--chart-1))';
  }

  return (
    <Card data-testid="trend-chart-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Disease Trends</CardTitle>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40" data-testid="time-range-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 3 months</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80" data-testid="chart-container">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="name" 
                tick={{ fill: 'hsl(var(--foreground))', fontSize: 12 }}
                stroke="hsl(var(--border))"
              />
              <YAxis 
                tick={{ fill: 'hsl(var(--foreground))', fontSize: 12 }}
                stroke="hsl(var(--border))"
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: 'var(--radius)',
                  color: 'hsl(var(--foreground))',
                }}
                labelStyle={{ color: 'hsl(var(--foreground))' }}
              />
              <Bar 
                dataKey="cases" 
                fill="hsl(var(--primary))"
                radius={[4, 4, 0, 0]}
                className="chart-enter"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        {/* Time period indicators */}
        <div className="flex justify-between text-xs text-muted-foreground mt-4 px-4" data-testid="time-indicators">
          <span>Week 1</span>
          <span>Week 2</span>
          <span>Week 3</span>
          <span>Week 4</span>
        </div>
      </CardContent>
    </Card>
  );
}
