import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { MessageSquare, Mail, MessageCircle } from "lucide-react";

export default function CommunicationStatus() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const channels = [
    {
      name: "SMS Alerts (Twilio)",
      description: "Emergency notifications",
      icon: MessageSquare,
      color: "primary",
      status: "Active",
      statusColor: "bg-secondary text-secondary-foreground",
    },
    {
      name: "Email (SendGrid)",
      description: "Health updates & reports",
      icon: Mail,
      color: "accent",
      status: "Active",
      statusColor: "bg-secondary text-secondary-foreground",
    },
    {
      name: "WhatsApp Business",
      description: "Community messaging",
      icon: MessageCircle,
      color: "secondary",
      status: "Active",
      statusColor: "bg-secondary text-secondary-foreground",
    },
  ];

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-40 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="communication-status">
      <CardHeader>
        <CardTitle>Communication Channels</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {channels.map((channel) => {
            const Icon = channel.icon;
            return (
              <div
                key={channel.name}
                className="flex items-center justify-between p-4 bg-muted rounded-lg"
                data-testid={`channel-${channel.name.toLowerCase().replace(/[^\w]/g, '-')}`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 bg-${channel.color} rounded-lg flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 text-${channel.color}-foreground`} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {channel.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {channel.description}
                    </p>
                  </div>
                </div>
                <Badge className={channel.statusColor}>
                  {channel.status}
                </Badge>
              </div>
            );
          })}
        </div>
        
        {/* Recent Activity */}
        <div className="mt-6">
          <h4 className="text-sm font-medium text-foreground mb-3">Recent Communication Activity</h4>
          <div className="space-y-2 text-sm" data-testid="communication-activity">
            <div className="flex justify-between">
              <span className="text-muted-foreground">SMS alerts sent today</span>
              <span className="text-foreground font-medium">1,247</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Emails delivered</span>
              <span className="text-foreground font-medium">3,542</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">WhatsApp messages</span>
              <span className="text-foreground font-medium">892</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
