import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, MapPin, Droplet, Hospital } from "lucide-react";
import type { DashboardStats } from "@/lib/types";

export default function MetricsCards() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const metrics = [
    {
      title: "Active Cases",
      value: stats?.activeCases || 0,
      change: "+12%",
      changeType: "increase",
      icon: Users,
      color: "destructive",
      description: "from last week",
    },
    {
      title: "High Risk Areas",
      value: stats?.highRiskAreas || 0,
      change: "+3",
      changeType: "increase",
      icon: MapPin,
      color: "accent",
      description: "new this week",
    },
    {
      title: "Water Quality Index",
      value: `${stats?.waterQualityIndex || 68}/100`,
      change: "Moderate",
      changeType: "neutral",
      icon: Droplet,
      color: "primary",
      description: "status",
    },
    {
      title: "Hospitals Available",
      value: stats?.hospitalsAvailable || 0,
      change: "89%",
      changeType: "neutral",
      icon: Hospital,
      color: "secondary",
      description: "capacity",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {metrics.map((metric, index) => {
        const Icon = metric.icon;
        return (
          <Card key={index} className="transition-all hover:shadow-md" data-testid={`metric-card-${metric.title.toLowerCase().replace(/\s+/g, '-')}`}>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className={`w-8 h-8 bg-${metric.color} rounded-lg flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 text-${metric.color}-foreground`} />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-muted-foreground truncate">
                      {metric.title}
                    </dt>
                    <dd className="text-lg font-medium text-foreground" data-testid={`metric-value-${metric.title.toLowerCase().replace(/\s+/g, '-')}`}>
                      {metric.value.toLocaleString()}
                    </dd>
                  </dl>
                </div>
              </div>
              <div className="mt-4">
                <div className="flex items-center text-sm">
                  <span 
                    className={`font-medium ${
                      metric.changeType === 'increase' 
                        ? 'text-destructive' 
                        : metric.changeType === 'neutral'
                        ? `text-${metric.color}`
                        : 'text-secondary'
                    }`}
                    data-testid={`metric-change-${metric.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {metric.change}
                  </span>
                  <span className="text-muted-foreground ml-2">
                    {metric.description}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
