import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Calendar as CalendarIcon, Clock } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import type { Hospital } from "@/lib/types";

const MOCK_USER_ID = "user-123"; // In a real app, this would come from auth context

interface BookingFormProps {
  onSuccess: () => void;
  hospitals: Hospital[];
}

export default function BookingForm({ onSuccess, hospitals }: BookingFormProps) {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState("");
  const [selectedHospital, setSelectedHospital] = useState("");
  const [department, setDepartment] = useState("");
  const [doctorName, setDoctorName] = useState("");
  const [purpose, setPurpose] = useState("");
  const [notes, setNotes] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const timeSlots = [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
    "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00"
  ];

  const departments = [
    "General Medicine", "Gastroenterology", "Infectious Disease", 
    "Emergency Medicine", "Internal Medicine", "Pediatrics"
  ];

  const bookingMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/appointments", {
        ...data,
        userId: MOCK_USER_ID,
        appointmentDate: new Date(`${format(selectedDate!, "yyyy-MM-dd")} ${selectedTime}`).toISOString(),
        status: "scheduled",
      });
    },
    onSuccess: () => {
      toast({
        title: "Appointment Booked",
        description: "Your appointment has been successfully scheduled. You will receive a confirmation email shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/appointments", MOCK_USER_ID] });
      onSuccess();
    },
    onError: () => {
      toast({
        title: "Booking Failed",
        description: "There was an error booking your appointment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDate || !selectedTime || !selectedHospital || !purpose.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    bookingMutation.mutate({
      hospitalId: selectedHospital,
      purpose: purpose.trim(),
      department: department || undefined,
      doctorName: doctorName.trim() || undefined,
      notes: notes.trim() || undefined,
    });
  };

  const selectedHospitalData = hospitals.find(h => h.id === selectedHospital);

  return (
    <form onSubmit={handleSubmit} className="space-y-6" data-testid="booking-form">
      {/* Hospital Selection */}
      <div className="space-y-2">
        <Label htmlFor="hospital">Hospital / Clinic *</Label>
        <Select value={selectedHospital} onValueChange={setSelectedHospital} required>
          <SelectTrigger data-testid="hospital-select">
            <SelectValue placeholder="Select a healthcare facility" />
          </SelectTrigger>
          <SelectContent>
            {hospitals.map((hospital) => (
              <SelectItem key={hospital.id} value={hospital.id}>
                <div>
                  <div className="font-medium">{hospital.name}</div>
                  <div className="text-sm text-muted-foreground">{hospital.address}</div>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedHospitalData && (
          <div className="text-sm text-muted-foreground">
            <p>📞 {selectedHospitalData.phone || "Phone not available"}</p>
            <p>🏥 {selectedHospitalData.type} • Emergency: {selectedHospitalData.emergencyServices ? "Yes" : "No"}</p>
          </div>
        )}
      </div>

      {/* Department */}
      <div className="space-y-2">
        <Label htmlFor="department">Department</Label>
        <Select value={department} onValueChange={setDepartment}>
          <SelectTrigger data-testid="department-select">
            <SelectValue placeholder="Select department (optional)" />
          </SelectTrigger>
          <SelectContent>
            {departments.map((dept) => (
              <SelectItem key={dept} value={dept}>{dept}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Doctor Name */}
      <div className="space-y-2">
        <Label htmlFor="doctor">Preferred Doctor (optional)</Label>
        <Input
          id="doctor"
          placeholder="Enter doctor's name"
          value={doctorName}
          onChange={(e) => setDoctorName(e.target.value)}
          data-testid="doctor-input"
        />
      </div>

      {/* Date and Time Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Preferred Date *</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !selectedDate && "text-muted-foreground"
                )}
                data-testid="date-picker-trigger"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                disabled={(date) => date < new Date() || date < new Date("1900-01-01")}
                initialFocus
                data-testid="date-calendar"
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label>Preferred Time *</Label>
          <Select value={selectedTime} onValueChange={setSelectedTime} required>
            <SelectTrigger data-testid="time-select">
              <SelectValue placeholder="Select time slot" />
            </SelectTrigger>
            <SelectContent>
              {timeSlots.map((time) => (
                <SelectItem key={time} value={time}>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4" />
                    <span>{time}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Purpose */}
      <div className="space-y-2">
        <Label htmlFor="purpose">Purpose of Visit *</Label>
        <Select value={purpose} onValueChange={setPurpose} required>
          <SelectTrigger data-testid="purpose-select">
            <SelectValue placeholder="Select purpose of visit" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="general-checkup">General Health Checkup</SelectItem>
            <SelectItem value="waterborne-symptoms">Waterborne Disease Symptoms</SelectItem>
            <SelectItem value="diarrhea-treatment">Diarrhea Treatment</SelectItem>
            <SelectItem value="fever-consultation">Fever Consultation</SelectItem>
            <SelectItem value="stomach-issues">Stomach/Abdominal Issues</SelectItem>
            <SelectItem value="follow-up">Follow-up Visit</SelectItem>
            <SelectItem value="vaccination">Vaccination</SelectItem>
            <SelectItem value="emergency">Emergency Consultation</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Additional Notes */}
      <div className="space-y-2">
        <Label htmlFor="notes">Additional Notes</Label>
        <Textarea
          id="notes"
          placeholder="Describe your symptoms, concerns, or any other relevant information..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={4}
          data-testid="notes-textarea"
        />
      </div>

      {/* Important Information */}
      <div className="bg-primary/10 p-4 rounded-lg">
        <h4 className="font-medium text-foreground mb-2">Important Information:</h4>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>• Appointments are subject to doctor availability</li>
          <li>• You will receive SMS and email confirmation</li>
          <li>• Please arrive 15 minutes before your scheduled time</li>
          <li>• Bring valid ID and any relevant medical documents</li>
          <li>• For emergencies, call 108 or visit the nearest emergency room</li>
        </ul>
      </div>

      {/* Submit Buttons */}
      <div className="flex justify-end space-x-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onSuccess}>
          Cancel
        </Button>
        <Button 
          type="submit"
          disabled={bookingMutation.isPending}
          data-testid="submit-booking"
        >
          {bookingMutation.isPending ? "Booking..." : "Book Appointment"}
        </Button>
      </div>
    </form>
  );
}
