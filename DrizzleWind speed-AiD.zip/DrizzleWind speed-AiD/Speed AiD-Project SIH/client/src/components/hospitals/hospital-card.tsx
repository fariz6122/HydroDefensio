import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import BookingForm from "@/components/appointments/booking-form";
import { 
  MapPin, Phone, Mail, Globe, Clock, Users, 
  Shield, Calendar, Star, Navigation 
} from "lucide-react";
import type { Hospital } from "@/lib/types";

interface HospitalCardProps {
  hospital: Hospital;
}

export default function HospitalCard({ hospital }: HospitalCardProps) {
  const [showBookingDialog, setShowBookingDialog] = useState(false);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'government': return 'bg-secondary text-secondary-foreground';
      case 'private': return 'bg-primary text-primary-foreground';
      case 'clinic': return 'bg-accent text-accent-foreground';
      case 'specialized': return 'bg-chart-4 text-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getOccupancyColor = (percentage: number) => {
    if (percentage < 60) return 'text-secondary';
    if (percentage < 80) return 'text-accent';
    return 'text-destructive';
  };

  const occupancyPercentage = hospital.capacity ? 
    Math.round(((hospital.currentOccupancy || 0) / hospital.capacity) * 100) : 0;

  return (
    <Card className="h-full hover:shadow-lg transition-shadow" data-testid={`hospital-card-${hospital.id}`}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg leading-tight mb-2">{hospital.name}</CardTitle>
            <div className="flex items-start space-x-2 text-muted-foreground">
              <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <p className="text-sm">{hospital.address}</p>
            </div>
          </div>
          <Badge className={getTypeColor(hospital.type)}>
            {hospital.type}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Contact Information */}
        <div className="space-y-2">
          {hospital.phone && (
            <div className="flex items-center space-x-2 text-sm">
              <Phone className="w-4 h-4 text-muted-foreground" />
              <a href={`tel:${hospital.phone}`} className="text-primary hover:underline">
                {hospital.phone}
              </a>
            </div>
          )}
          
          {hospital.email && (
            <div className="flex items-center space-x-2 text-sm">
              <Mail className="w-4 h-4 text-muted-foreground" />
              <a href={`mailto:${hospital.email}`} className="text-primary hover:underline">
                {hospital.email}
              </a>
            </div>
          )}
          
          {hospital.website && (
            <div className="flex items-center space-x-2 text-sm">
              <Globe className="w-4 h-4 text-muted-foreground" />
              <a 
                href={hospital.website} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                Visit Website
              </a>
            </div>
          )}
        </div>

        {/* Capacity Information */}
        {hospital.capacity && (
          <div className="bg-muted p-3 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">Capacity</span>
              </div>
              <span className={`text-sm font-medium ${getOccupancyColor(occupancyPercentage)}`}>
                {occupancyPercentage}% occupied
              </span>
            </div>
            <div className="text-xs text-muted-foreground">
              {hospital.currentOccupancy || 0} / {hospital.capacity} beds
            </div>
          </div>
        )}

        {/* Emergency Services */}
        {hospital.emergencyServices && (
          <div className="flex items-center space-x-2 p-2 bg-destructive/10 rounded-lg">
            <Shield className="w-4 h-4 text-destructive" />
            <span className="text-sm font-medium text-destructive">24/7 Emergency Services</span>
          </div>
        )}

        {/* Services */}
        {hospital.services.length > 0 && (
          <div>
            <h4 className="text-sm font-medium text-foreground mb-2">Services:</h4>
            <div className="flex flex-wrap gap-1">
              {hospital.services.slice(0, 3).map((service, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {service}
                </Badge>
              ))}
              {hospital.services.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{hospital.services.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Specializations */}
        {hospital.specializations.length > 0 && (
          <div>
            <h4 className="text-sm font-medium text-foreground mb-2">Specializations:</h4>
            <div className="flex flex-wrap gap-1">
              {hospital.specializations.slice(0, 2).map((spec, index) => (
                <Badge key={index} variant="outline" className="text-xs bg-primary/10 text-primary">
                  {spec}
                </Badge>
              ))}
              {hospital.specializations.length > 2 && (
                <Badge variant="outline" className="text-xs bg-primary/10 text-primary">
                  +{hospital.specializations.length - 2} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex space-x-2 pt-4 border-t">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
            onClick={() => {
              const coords = `${hospital.latitude},${hospital.longitude}`;
              window.open(`https://www.google.com/maps?q=${coords}`, '_blank');
            }}
            data-testid={`directions-${hospital.id}`}
          >
            <Navigation className="w-4 h-4 mr-1" />
            Directions
          </Button>
          
          <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="flex-1" data-testid={`book-appointment-${hospital.id}`}>
                <Calendar className="w-4 h-4 mr-1" />
                Book
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Book Appointment at {hospital.name}</DialogTitle>
              </DialogHeader>
              <BookingForm 
                onSuccess={() => setShowBookingDialog(false)}
                hospitals={[hospital]}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Quick Info */}
        <div className="flex items-center justify-between text-xs text-muted-foreground pt-2">
          <div className="flex items-center space-x-1">
            <Clock className="w-3 h-3" />
            <span>24/7</span>
          </div>
          <div className="flex items-center space-x-1">
            <Star className="w-3 h-3" />
            <span>4.2 rating</span>
          </div>
          <div className="text-xs">
            {Math.round(Math.random() * 5 + 1)}km away
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
