import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { EmergencyAlertDialog } from "@/components/communication/emergency-alert-dialog";
import { 
  AlertTriangle, Bell, ChevronDown, Menu, X
} from "lucide-react";

interface TopHeaderProps {
  title: string;
  subtitle?: string;
  onMobileMenuToggle?: () => void;
  isMobileMenuOpen?: boolean;
}

export default function TopHeader({ 
  title, 
  subtitle, 
  onMobileMenuToggle, 
  isMobileMenuOpen 
}: TopHeaderProps) {
  const [showEmergencyDialog, setShowEmergencyDialog] = useState(false);

  return (
    <>
      <header className="bg-card border-b border-border">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button 
                type="button" 
                className="lg:hidden -ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-muted-foreground hover:text-foreground focus:outline-none focus:ring-2 focus:ring-inset focus:ring-ring"
                onClick={onMobileMenuToggle}
                data-testid="mobile-menu-button"
              >
                {isMobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
              
              <div className="hidden lg:block">
                <h1 className="text-2xl font-semibold text-foreground" data-testid="page-title">
                  {title}
                </h1>
                {subtitle && (
                  <p className="text-sm text-muted-foreground" data-testid="page-subtitle">
                    {subtitle}
                  </p>
                )}
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Emergency Alert Button */}
              <Dialog open={showEmergencyDialog} onOpenChange={setShowEmergencyDialog}>
                <DialogTrigger asChild>
                  <Button 
                    variant="destructive" 
                    size="sm" 
                    className="flex items-center space-x-2"
                    data-testid="emergency-alert-button"
                  >
                    <AlertTriangle className="w-4 h-4" />
                    <span className="hidden sm:inline">Emergency Alert</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Send Emergency Alert</DialogTitle>
                  </DialogHeader>
                  <EmergencyAlertDialog onClose={() => setShowEmergencyDialog(false)} />
                </DialogContent>
              </Dialog>
              
              {/* Notification Bell */}
              <button 
                className="relative p-2 text-muted-foreground hover:text-foreground rounded-md transition-colors"
                data-testid="notifications-button"
              >
                <Bell className="w-5 h-5" />
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs p-0"
                  data-testid="notification-badge"
                >
                  3
                </Badge>
              </button>
              
              {/* User Menu */}
              <div className="relative">
                <button 
                  className="flex items-center space-x-2 text-sm rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                  data-testid="user-menu-button"
                >
                  <img 
                    className="h-8 w-8 rounded-full" 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                    alt="User avatar"
                    data-testid="header-user-avatar"
                  />
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}
