import { useState, useEffect } from "react";
import Sidebar from "./sidebar";
import TopHeader from "./top-header";
import { cn } from "@/lib/utils";

interface MainLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
}

export default function MainLayout({ children, title, subtitle }: MainLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Close mobile menu on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, []);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      {/* Mobile Navigation Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 z-40 bg-background/80 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
          data-testid="mobile-nav-overlay"
        >
          <div className="fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border">
            {/* Mobile sidebar content */}
            <Sidebar />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="lg:pl-64 flex flex-col flex-1 min-w-0">
        <TopHeader
          title={title}
          subtitle={subtitle}
          onMobileMenuToggle={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          isMobileMenuOpen={isMobileMenuOpen}
        />
        
        <main className="flex-1 pb-8 overflow-auto" data-testid="main-content">
          <div className="px-4 sm:px-6 lg:px-8 mt-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
