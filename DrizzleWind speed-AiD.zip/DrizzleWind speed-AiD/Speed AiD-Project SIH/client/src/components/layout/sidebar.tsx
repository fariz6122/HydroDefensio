import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Activity, LayoutDashboard, MapPin, TrendingUp, Droplet, 
  Stethoscope, BookOpen, Calendar, Hospital, Bell, Settings,
  Shield
} from "lucide-react";

const navigationItems = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Risk Map", href: "/risk-map", icon: MapPin },
  { name: "Disease Trends", href: "/disease-trends", icon: TrendingUp },
  { name: "Water Quality", href: "/water-quality", icon: Droplet },
  { name: "Symptom Checker", href: "/symptom-checker", icon: Stethoscope },
  { name: "Health Diary", href: "/health-diary", icon: BookOpen },
  { name: "Appointments", href: "/appointments", icon: Calendar },
  { name: "Hospitals", href: "/hospitals", icon: Hospital },
  { name: "Alerts", href: "/alerts", icon: Bell },
  { name: "Settings", href: "/settings", icon: Settings },
  { name: "Admin", href: "/admin", icon: Shield },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0">
      <div className="flex flex-col flex-grow bg-card border-r border-border pt-5 pb-4 overflow-y-auto">
        <div className="flex items-center flex-shrink-0 px-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Activity className="w-5 h-5 text-primary-foreground" data-testid="logo-icon" />
              </div>
            </div>
            <div className="ml-3">
              <h1 className="text-lg font-semibold text-foreground" data-testid="app-title">
                SPEED AiD
              </h1>
              <p className="text-xs text-muted-foreground" data-testid="app-subtitle">
                Disease Monitor
              </p>
            </div>
          </div>
        </div>
        
        <nav className="mt-8 flex-1 px-2 space-y-1" data-testid="sidebar-navigation">
          {navigationItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link key={item.name} href={item.href}>
                <a
                  className={cn(
                    "group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                  data-testid={`nav-${item.name.toLowerCase().replace(' ', '-')}`}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {item.name}
                </a>
              </Link>
            );
          })}
        </nav>
        
        <div className="flex-shrink-0 flex border-t border-border p-4">
          <div className="flex-shrink-0 w-full group block">
            <div className="flex items-center">
              <div>
                <img 
                  className="inline-block h-9 w-9 rounded-full" 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                  alt="User avatar"
                  data-testid="user-avatar"
                />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-foreground" data-testid="user-name">
                  Dr. Sarah Johnson
                </p>
                <p className="text-xs font-medium text-muted-foreground" data-testid="user-role">
                  Health Official
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
