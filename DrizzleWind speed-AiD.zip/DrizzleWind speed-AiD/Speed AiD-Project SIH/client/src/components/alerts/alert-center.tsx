import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/hooks/use-websocket";
import { AlertTriangle, Send, Zap, Users, Globe } from "lucide-react";
import type { EmergencyAlertResult } from "@/lib/types";

export default function AlertCenter() {
  const [showQuickAlert, setShowQuickAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [alertType, setAlertType] = useState("health");
  const [targetArea, setTargetArea] = useState("all");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isConnected, lastMessage } = useWebSocket();

  const quickAlertMutation = useMutation({
    mutationFn: async (data: { message: string; type: string; targetArea: string }) => {
      const response = await apiRequest("POST", "/api/notifications/emergency", {
        message: data.message,
        priority: data.type === "emergency" ? "critical" : "high",
        targetArea: data.targetArea,
      });
      return response.json();
    },
    onSuccess: (data) => {
      const result = data.communicationResult as EmergencyAlertResult;
      toast({
        title: "Alert Sent Successfully",
        description: `Delivered to ${result.total} recipients via ${result.email} emails, ${result.sms} SMS, and ${result.whatsapp} WhatsApp messages.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      setShowQuickAlert(false);
      setAlertMessage("");
    },
    onError: () => {
      toast({
        title: "Alert Failed",
        description: "Failed to send the alert. Please try again.",
        variant: "destructive",
      });
    },
  });

  const predefinedAlerts = [
    {
      title: "Cholera Outbreak Warning",
      message: "High risk cholera outbreak detected in your area. Avoid untreated water sources and seek medical attention if experiencing symptoms.",
      type: "emergency",
      icon: AlertTriangle,
    },
    {
      title: "Water Contamination Alert",
      message: "Water quality testing shows contamination in municipal supply. Boil water before consumption until further notice.",
      type: "health",
      icon: Zap,
    },
    {
      title: "Health Advisory Update",
      message: "New prevention guidelines for waterborne diseases have been issued by the Health Ministry. Check your health diary for details.",
      type: "info",
      icon: Users,
    },
  ];

  return (
    <Card data-testid="alert-center">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Zap className="w-5 h-5 text-primary" />
          <span>Quick Alert Center</span>
          {!isConnected && (
            <Badge variant="outline" className="bg-destructive/10 text-destructive">
              Offline
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* WebSocket Status */}
        {lastMessage && (
          <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
            <p className="text-sm font-medium text-primary">
              Real-time Update: {lastMessage.message || "System connected"}
            </p>
          </div>
        )}

        {/* Predefined Alert Templates */}
        <div>
          <h3 className="font-medium text-foreground mb-3">Quick Templates</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {predefinedAlerts.map((alert, index) => {
              const Icon = alert.icon;
              return (
                <Card key={index} className="cursor-pointer hover:shadow-sm transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-2">
                      <Icon className="w-5 h-5 text-destructive" />
                      <h4 className="font-medium text-sm">{alert.title}</h4>
                    </div>
                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                      {alert.message}
                    </p>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        setAlertMessage(alert.message);
                        setAlertType(alert.type);
                        setShowQuickAlert(true);
                      }}
                      data-testid={`template-${index}`}
                    >
                      Use Template
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Custom Alert Dialog */}
        <Dialog open={showQuickAlert} onOpenChange={setShowQuickAlert}>
          <DialogTrigger asChild>
            <Button className="w-full" data-testid="custom-alert-button">
              <Send className="w-4 h-4 mr-2" />
              Send Custom Alert
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Send Quick Alert</DialogTitle>
            </DialogHeader>
            <div className="space-y-4" data-testid="quick-alert-form">
              <div className="space-y-2">
                <Label htmlFor="alert-type">Alert Type</Label>
                <Select value={alertType} onValueChange={setAlertType}>
                  <SelectTrigger data-testid="alert-type-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="emergency">Emergency - Critical</SelectItem>
                    <SelectItem value="health">Health Alert - High</SelectItem>
                    <SelectItem value="info">Information - Medium</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="target-area">Target Area</Label>
                <Select value={targetArea} onValueChange={setTargetArea}>
                  <SelectTrigger data-testid="target-area-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">
                      <div className="flex items-center space-x-2">
                        <Globe className="w-4 h-4" />
                        <span>All Users</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="guwahati">Guwahati Region</SelectItem>
                    <SelectItem value="silchar">Silchar Region</SelectItem>
                    <SelectItem value="itanagar">Itanagar Region</SelectItem>
                    <SelectItem value="imphal">Imphal Region</SelectItem>
                    <SelectItem value="aizawl">Aizawl Region</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="alert-message">Alert Message</Label>
                <Textarea
                  id="alert-message"
                  placeholder="Enter your alert message..."
                  value={alertMessage}
                  onChange={(e) => setAlertMessage(e.target.value)}
                  rows={4}
                  data-testid="alert-message-input"
                />
              </div>

              <div className="bg-muted p-3 rounded-lg">
                <h4 className="text-sm font-medium text-foreground mb-2">Distribution Preview:</h4>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>• SMS alerts will be sent immediately</p>
                  <p>• Email notifications with detailed information</p>
                  <p>• WhatsApp messages to subscribed users</p>
                  <p>• Real-time dashboard updates</p>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowQuickAlert(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={() => quickAlertMutation.mutate({ message: alertMessage, type: alertType, targetArea })}
                  disabled={!alertMessage.trim() || quickAlertMutation.isPending}
                  data-testid="send-quick-alert"
                >
                  {quickAlertMutation.isPending ? "Sending..." : "Send Alert"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Alert Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-3 bg-destructive/10 rounded-lg">
            <div className="text-lg font-bold text-destructive">24</div>
            <div className="text-xs text-muted-foreground">Alerts Today</div>
          </div>
          <div className="text-center p-3 bg-secondary/10 rounded-lg">
            <div className="text-lg font-bold text-secondary">98.5%</div>
            <div className="text-xs text-muted-foreground">Delivery Rate</div>
          </div>
          <div className="text-center p-3 bg-primary/10 rounded-lg">
            <div className="text-lg font-bold text-primary">2.3s</div>
            <div className="text-xs text-muted-foreground">Avg Response Time</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
