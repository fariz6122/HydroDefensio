import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import RiskMap from "@/pages/risk-map";
import DiseaseTrends from "@/pages/disease-trends";
import WaterQuality from "@/pages/water-quality";
import SymptomChecker from "@/pages/symptom-checker";
import HealthDiary from "@/pages/health-diary";
import Appointments from "@/pages/appointments";
import Hospitals from "@/pages/hospitals";
import Alerts from "@/pages/alerts";
import Settings from "@/pages/settings";
import AdminDashboard from "@/pages/admin-dashboard";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/risk-map" component={RiskMap} />
      <Route path="/disease-trends" component={DiseaseTrends} />
      <Route path="/water-quality" component={WaterQuality} />
      <Route path="/symptom-checker" component={SymptomChecker} />
      <Route path="/health-diary" component={HealthDiary} />
      <Route path="/appointments" component={Appointments} />
      <Route path="/hospitals" component={Hospitals} />
      <Route path="/alerts" component={Alerts} />
      <Route path="/settings" component={Settings} />
      <Route path="/admin" component={AdminDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
