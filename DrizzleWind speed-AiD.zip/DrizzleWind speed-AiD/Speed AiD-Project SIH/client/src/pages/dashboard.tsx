import { useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import MetricsCards from "@/components/dashboard/metrics-cards";
import DiseaseMap from "@/components/dashboard/disease-map";
import TrendChart from "@/components/dashboard/trend-chart";
import WaterQualityMonitor from "@/components/dashboard/water-quality-monitor";
import AlertsFeed from "@/components/dashboard/alerts-feed";
import QuickActions from "@/components/dashboard/quick-actions";
import CommunicationStatus from "@/components/dashboard/communication-status";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";

export default function Dashboard() {
  const [showAlert, setShowAlert] = useState(true);
  const { isConnected, lastMessage } = useWebSocket();

  return (
    <MainLayout
      title="Disease Monitoring Dashboard"
      subtitle="Real-time waterborne disease surveillance for Northeast India"
    >
      {/* Emergency Alert Banner */}
      {showAlert && (
        <Alert className="bg-accent text-accent-foreground mb-6" data-testid="emergency-alert-banner">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <span className="text-sm font-medium">
              High Risk Alert: Cholera outbreak detected in Guwahati region. Immediate action required.
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAlert(false)}
              className="text-accent-foreground hover:text-accent-foreground/80"
              data-testid="dismiss-alert-button"
            >
              <X className="h-4 w-4" />
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* WebSocket Status */}
      {!isConnected && (
        <Alert className="bg-muted mb-6" data-testid="websocket-status">
          <AlertDescription>
            Real-time updates are currently unavailable. Refresh the page to reconnect.
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-8">
        {/* Key Metrics */}
        <section data-testid="metrics-section">
          <MetricsCards />
        </section>

        {/* Main Dashboard Grid */}
        <section className="grid grid-cols-1 gap-8 lg:grid-cols-2" data-testid="main-dashboard-grid">
          <DiseaseMap />
          <TrendChart />
          <WaterQualityMonitor />
          <AlertsFeed />
        </section>

        {/* Quick Actions */}
        <section data-testid="quick-actions-section">
          <QuickActions />
        </section>

        {/* Communication Status */}
        <section data-testid="communication-section">
          <CommunicationStatus />
        </section>
      </div>
    </MainLayout>
  );
}
