import { useQuery, useMutation } from "@tanstack/react-query";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Droplet, RefreshCw, MapPin, Activity } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { WaterQualityData } from "@/lib/types";

export default function WaterQuality() {
  const { toast } = useToast();
  
  const { data: waterData, isLoading, refetch } = useQuery<WaterQualityData[]>({
    queryKey: ["/api/water-quality"],
    refetchInterval: 30000, // Auto-refresh every 30 seconds
  });

  const simulateDataMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/water-quality/simulate", {}),
    onSuccess: () => {
      toast({
        title: "Data Updated",
        description: "Water quality sensors have been refreshed with latest readings.",
      });
      refetch();
    },
  });

  const getQualityLevel = (ph: number, turbidity: number, ecoli: number) => {
    if (ph < 6.5 || ph > 8.5 || turbidity > 5 || ecoli > 10) return 'Poor';
    if (ph < 7 || ph > 8 || turbidity > 3 || ecoli > 5) return 'Fair';
    if (ph >= 7 && ph <= 8 && turbidity <= 1 && ecoli === 0) return 'Excellent';
    return 'Good';
  };

  const getQualityColor = (level: string) => {
    switch (level) {
      case 'Excellent': return 'text-secondary';
      case 'Good': return 'text-primary';
      case 'Fair': return 'text-accent';
      case 'Poor': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active': return 'bg-secondary text-secondary-foreground';
      case 'maintenance': return 'bg-accent text-accent-foreground';
      case 'offline': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  // Process data for chart
  const chartData = waterData?.slice(0, 10).map((data, index) => ({
    name: data.location.split(' - ')[1] || `Sensor ${index + 1}`,
    ph: parseFloat(data.ph || "7"),
    turbidity: parseFloat(data.turbidity || "3"),
    dissolvedOxygen: parseFloat(data.dissolvedOxygen || "8"),
    ecoliCount: data.ecoliCount || 0,
  })) || [];

  if (isLoading) {
    return (
      <MainLayout 
        title="Water Quality Monitoring" 
        subtitle="Real-time water quality data from sensors across Northeast India"
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-60 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      title="Water Quality Monitoring" 
      subtitle="Real-time water quality data from sensors across Northeast India"
    >
      <div className="space-y-6">
        {/* Control Panel */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <Droplet className="w-5 h-5 text-primary" />
                <span>Monitoring Dashboard</span>
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Badge className="bg-secondary text-secondary-foreground">
                  <Activity className="w-3 h-3 mr-1" />
                  Live Data
                </Badge>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => simulateDataMutation.mutate()}
                  disabled={simulateDataMutation.isPending}
                  data-testid="refresh-data-button"
                >
                  <RefreshCw className={`w-4 h-4 ${simulateDataMutation.isPending ? 'animate-spin' : ''}`} />
                  Refresh
                </Button>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Sensor Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {waterData?.slice(0, 6).map((sensor) => {
            const ph = parseFloat(sensor.ph || "7");
            const turbidity = parseFloat(sensor.turbidity || "3");
            const ecoli = sensor.ecoliCount || 0;
            const qualityLevel = getQualityLevel(ph, turbidity, ecoli);

            return (
              <Card key={sensor.id} className="water-ripple" data-testid={`sensor-card-${sensor.sensorId}`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{sensor.sensorId}</CardTitle>
                      <p className="text-sm text-muted-foreground flex items-center">
                        <MapPin className="w-3 h-3 mr-1" />
                        {sensor.location}
                      </p>
                    </div>
                    <Badge className={getStatusBadge(sensor.status)}>
                      {sensor.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Overall Quality */}
                    <div className="text-center">
                      <div className={`text-2xl font-bold ${getQualityColor(qualityLevel)}`}>
                        {qualityLevel}
                      </div>
                      <div className="text-sm text-muted-foreground">Water Quality</div>
                    </div>

                    {/* Metrics */}
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>pH Level</span>
                          <span className="font-medium">{ph.toFixed(1)}</span>
                        </div>
                        <Progress 
                          value={((ph - 6) / 3) * 100} 
                          className="h-2"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Turbidity (NTU)</span>
                          <span className="font-medium">{turbidity.toFixed(1)}</span>
                        </div>
                        <Progress 
                          value={(turbidity / 10) * 100} 
                          className="h-2"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Dissolved O₂ (mg/L)</span>
                          <span className="font-medium">
                            {parseFloat(sensor.dissolvedOxygen || "8").toFixed(1)}
                          </span>
                        </div>
                        <Progress 
                          value={(parseFloat(sensor.dissolvedOxygen || "8") / 15) * 100} 
                          className="h-2"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>E. coli (CFU/100ml)</span>
                          <span className="font-medium">{ecoli}</span>
                        </div>
                        <Progress 
                          value={Math.min((ecoli / 100) * 100, 100)} 
                          className="h-2"
                        />
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground">
                      Last updated: {new Date(sensor.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          }) || (
            <div className="col-span-full text-center py-8">
              <p className="text-muted-foreground">No sensor data available</p>
            </div>
          )}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* pH Levels Chart */}
          <Card data-testid="ph-chart">
            <CardHeader>
              <CardTitle>pH Levels Across Sensors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="name" 
                      tick={{ fill: 'hsl(var(--foreground))', fontSize: 12 }}
                      stroke="hsl(var(--border))"
                    />
                    <YAxis 
                      domain={[6, 9]}
                      tick={{ fill: 'hsl(var(--foreground))', fontSize: 12 }}
                      stroke="hsl(var(--border))"
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                        color: 'hsl(var(--foreground))',
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="ph" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={3}
                      dot={{ fill: 'hsl(var(--primary))', r: 5 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Water Quality Summary */}
          <Card data-testid="quality-summary">
            <CardHeader>
              <CardTitle>Quality Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Quality Distribution */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-secondary/10 rounded-lg">
                    <div className="text-2xl font-bold text-secondary">
                      {waterData?.filter(d => {
                        const ph = parseFloat(d.ph || "7");
                        const turbidity = parseFloat(d.turbidity || "3");
                        const ecoli = d.ecoliCount || 0;
                        return getQualityLevel(ph, turbidity, ecoli) === 'Excellent';
                      }).length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Excellent</div>
                  </div>
                  <div className="text-center p-4 bg-primary/10 rounded-lg">
                    <div className="text-2xl font-bold text-primary">
                      {waterData?.filter(d => {
                        const ph = parseFloat(d.ph || "7");
                        const turbidity = parseFloat(d.turbidity || "3");
                        const ecoli = d.ecoliCount || 0;
                        return getQualityLevel(ph, turbidity, ecoli) === 'Good';
                      }).length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Good</div>
                  </div>
                  <div className="text-center p-4 bg-accent/10 rounded-lg">
                    <div className="text-2xl font-bold text-accent">
                      {waterData?.filter(d => {
                        const ph = parseFloat(d.ph || "7");
                        const turbidity = parseFloat(d.turbidity || "3");
                        const ecoli = d.ecoliCount || 0;
                        return getQualityLevel(ph, turbidity, ecoli) === 'Fair';
                      }).length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Fair</div>
                  </div>
                  <div className="text-center p-4 bg-destructive/10 rounded-lg">
                    <div className="text-2xl font-bold text-destructive">
                      {waterData?.filter(d => {
                        const ph = parseFloat(d.ph || "7");
                        const turbidity = parseFloat(d.turbidity || "3");
                        const ecoli = d.ecoliCount || 0;
                        return getQualityLevel(ph, turbidity, ecoli) === 'Poor';
                      }).length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Poor</div>
                  </div>
                </div>

                {/* Sensor Status */}
                <div className="border-t border-border pt-4">
                  <h4 className="font-medium mb-3">Sensor Network Status</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Active Sensors</span>
                      <span className="font-medium">
                        {waterData?.filter(d => d.status === 'active').length || 0}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Under Maintenance</span>
                      <span className="font-medium">
                        {waterData?.filter(d => d.status === 'maintenance').length || 0}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Offline</span>
                      <span className="font-medium">
                        {waterData?.filter(d => d.status === 'offline').length || 0}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Alerts */}
                <div className="border-t border-border pt-4">
                  <h4 className="font-medium mb-2">Quality Alerts</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>• pH levels outside safe range: {waterData?.filter(d => {
                      const ph = parseFloat(d.ph || "7");
                      return ph < 6.5 || ph > 8.5;
                    }).length || 0} sensors</p>
                    <p>• High E. coli detected: {waterData?.filter(d => 
                      (d.ecoliCount || 0) > 10
                    ).length || 0} sensors</p>
                    <p>• High turbidity: {waterData?.filter(d => 
                      parseFloat(d.turbidity || "0") > 5
                    ).length || 0} sensors</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
