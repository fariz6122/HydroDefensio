import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import MainLayout from "@/components/layout/main-layout";
import BookingForm from "@/components/appointments/booking-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Clock, MapPin, Phone, Plus, User } from "lucide-react";
import { format } from "date-fns";
import type { Appointment, Hospital } from "@/lib/types";

const MOCK_USER_ID = "user-123"; // In a real app, this would come from auth context

export default function Appointments() {
  const [showBookingDialog, setShowBookingDialog] = useState(false);

  const { data: appointments, isLoading: appointmentsLoading } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments", MOCK_USER_ID],
  });

  const { data: hospitals } = useQuery<Hospital[]>({
    queryKey: ["/api/hospitals"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-secondary text-secondary-foreground';
      case 'scheduled': return 'bg-primary text-primary-foreground';
      case 'completed': return 'bg-muted text-muted-foreground';
      case 'cancelled': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getHospitalName = (hospitalId: string) => {
    const hospital = hospitals?.find(h => h.id === hospitalId);
    return hospital?.name || 'Unknown Hospital';
  };

  if (appointmentsLoading) {
    return (
      <MainLayout title="Appointments" subtitle="Manage your healthcare appointments">
        <div className="space-y-6">
          <Skeleton className="h-40 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-48 w-full" />
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  const upcomingAppointments = appointments?.filter(apt => 
    new Date(apt.appointmentDate) > new Date() && apt.status !== 'cancelled'
  ) || [];
  
  const pastAppointments = appointments?.filter(apt => 
    new Date(apt.appointmentDate) <= new Date() || apt.status === 'cancelled'
  ) || [];

  return (
    <MainLayout title="Appointments" subtitle="Manage your healthcare appointments">
      <div className="space-y-6">
        {/* Header with Book Appointment Button */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-primary" />
                <span>Healthcare Appointments</span>
              </CardTitle>
              <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
                <DialogTrigger asChild>
                  <Button data-testid="book-appointment-button">
                    <Plus className="w-4 h-4 mr-2" />
                    Book Appointment
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Book New Appointment</DialogTitle>
                  </DialogHeader>
                  <BookingForm 
                    onSuccess={() => setShowBookingDialog(false)}
                    hospitals={hospitals || []}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{upcomingAppointments.length}</div>
                <div className="text-sm text-muted-foreground">Upcoming</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-secondary">
                  {appointments?.filter(a => a.status === 'confirmed').length || 0}
                </div>
                <div className="text-sm text-muted-foreground">Confirmed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-muted-foreground">
                  {appointments?.filter(a => a.status === 'completed').length || 0}
                </div>
                <div className="text-sm text-muted-foreground">Completed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-accent">
                  {appointments?.filter(a => a.status === 'cancelled').length || 0}
                </div>
                <div className="text-sm text-muted-foreground">Cancelled</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Appointments */}
        {upcomingAppointments.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-foreground">Upcoming Appointments</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {upcomingAppointments.map((appointment) => (
                <Card key={appointment.id} className="border-l-4 border-l-primary" data-testid={`appointment-${appointment.id}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-primary" />
                        <span className="font-medium">
                          {format(new Date(appointment.appointmentDate), "MMM dd, yyyy")}
                        </span>
                      </div>
                      <Badge className={getStatusColor(appointment.status)}>
                        {appointment.status}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-2 text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>{format(new Date(appointment.appointmentDate), "hh:mm a")}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start space-x-2">
                      <MapPin className="w-4 h-4 text-muted-foreground mt-1" />
                      <div>
                        <p className="font-medium text-foreground">
                          {getHospitalName(appointment.hospitalId)}
                        </p>
                        {appointment.department && (
                          <p className="text-sm text-muted-foreground">
                            Department: {appointment.department}
                          </p>
                        )}
                      </div>
                    </div>

                    {appointment.doctorName && (
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">Dr. {appointment.doctorName}</span>
                      </div>
                    )}

                    <div className="bg-muted p-3 rounded-lg">
                      <p className="text-sm font-medium text-foreground mb-1">Purpose:</p>
                      <p className="text-sm text-muted-foreground">{appointment.purpose}</p>
                    </div>

                    {appointment.notes && (
                      <div className="bg-muted p-3 rounded-lg">
                        <p className="text-sm font-medium text-foreground mb-1">Notes:</p>
                        <p className="text-sm text-muted-foreground">{appointment.notes}</p>
                      </div>
                    )}

                    <div className="flex space-x-2 pt-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        Reschedule
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Past Appointments */}
        {pastAppointments.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-foreground">Past Appointments</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pastAppointments.slice(0, 6).map((appointment) => (
                <Card key={appointment.id} className="hover:shadow-sm transition-shadow" data-testid={`past-appointment-${appointment.id}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium">
                        {format(new Date(appointment.appointmentDate), "MMM dd, yyyy")}
                      </div>
                      <Badge className={getStatusColor(appointment.status)} variant="outline">
                        {appointment.status}
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-foreground font-medium mb-1">
                      {getHospitalName(appointment.hospitalId)}
                    </p>
                    
                    <p className="text-xs text-muted-foreground mb-2">
                      {appointment.purpose}
                    </p>

                    {appointment.doctorName && (
                      <p className="text-xs text-muted-foreground">
                        Dr. {appointment.doctorName}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {(!appointments || appointments.length === 0) && (
          <Card>
            <CardContent className="text-center py-12">
              <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">No appointments scheduled yet.</p>
              <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Book Your First Appointment
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Book New Appointment</DialogTitle>
                  </DialogHeader>
                  <BookingForm 
                    onSuccess={() => setShowBookingDialog(false)}
                    hospitals={hospitals || []}
                  />
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        )}

        {/* Quick Tips */}
        <Card>
          <CardHeader>
            <CardTitle>Appointment Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-foreground mb-2">Before Your Visit:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Arrive 15 minutes early</li>
                  <li>• Bring valid ID and insurance cards</li>
                  <li>• List current medications</li>
                  <li>• Prepare questions for your doctor</li>
                </ul>
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-2">Emergency Contacts:</h3>
                <div className="text-sm space-y-1">
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4 text-primary" />
                    <span className="text-muted-foreground">Emergency: 108</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4 text-primary" />
                    <span className="text-muted-foreground">SPEED AiD Helpline: +91-1234567890</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
