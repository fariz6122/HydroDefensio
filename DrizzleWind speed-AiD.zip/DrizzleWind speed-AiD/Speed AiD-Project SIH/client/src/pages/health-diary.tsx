import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BookOpen, Plus, Calendar as CalendarIcon, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import type { HealthDiaryEntry } from "@/lib/types";

const MOCK_USER_ID = "user-123"; // In a real app, this would come from auth context

export default function HealthDiary() {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [formData, setFormData] = useState({
    symptoms: [] as string[],
    severityLevel: 5,
    waterConsumption: "",
    waterSource: "",
    foodIntake: "",
    activities: "",
    mood: "",
    notes: "",
    location: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: entries, isLoading } = useQuery<HealthDiaryEntry[]>({
    queryKey: ["/api/health-diary", MOCK_USER_ID],
  });

  const addEntryMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/health-diary", {
        ...data,
        userId: MOCK_USER_ID,
        date: selectedDate.toISOString(),
      });
    },
    onSuccess: () => {
      toast({
        title: "Entry Added",
        description: "Your health diary entry has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/health-diary", MOCK_USER_ID] });
      setShowAddDialog(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Failed to Save",
        description: "There was an error saving your diary entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      symptoms: [],
      severityLevel: 5,
      waterConsumption: "",
      waterSource: "",
      foodIntake: "",
      activities: "",
      mood: "",
      notes: "",
      location: "",
    });
    setSelectedDate(new Date());
  };

  const handleSymptomChange = (symptom: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({ ...prev, symptoms: [...prev.symptoms, symptom] }));
    } else {
      setFormData(prev => ({ ...prev, symptoms: prev.symptoms.filter(s => s !== symptom) }));
    }
  };

  const availableSymptoms = [
    'Diarrhea', 'Vomiting', 'Nausea', 'Stomach cramps', 'Fever', 
    'Headache', 'Fatigue', 'Dehydration', 'Loss of appetite'
  ];

  const getSeverityColor = (level: number) => {
    if (level <= 3) return 'bg-secondary text-secondary-foreground';
    if (level <= 6) return 'bg-chart-4 text-foreground';
    if (level <= 8) return 'bg-accent text-accent-foreground';
    return 'bg-destructive text-destructive-foreground';
  };

  if (isLoading) {
    return (
      <MainLayout title="Health Diary" subtitle="Track your daily health and symptoms">
        <div className="space-y-6">
          <Skeleton className="h-40 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-48 w-full" />
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Health Diary" subtitle="Track your daily health and symptoms">
      <div className="space-y-6">
        {/* Header with Add Entry Button */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <BookOpen className="w-5 h-5 text-primary" />
                <span>Personal Health Journal</span>
              </CardTitle>
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button data-testid="add-entry-button">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Entry
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add Health Diary Entry</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4" data-testid="add-entry-form">
                    {/* Date Selection */}
                    <div className="space-y-2">
                      <Label>Date</Label>
                      <div className="flex items-center space-x-2">
                        <CalendarIcon className="w-4 h-4 text-muted-foreground" />
                        <span>{format(selectedDate, "PPP")}</span>
                      </div>
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={(date) => date && setSelectedDate(date)}
                        className="rounded-md border"
                        data-testid="entry-date-calendar"
                      />
                    </div>

                    {/* Symptoms */}
                    <div className="space-y-2">
                      <Label>Symptoms (select all that apply)</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {availableSymptoms.map((symptom) => (
                          <div key={symptom} className="flex items-center space-x-2">
                            <Checkbox
                              id={`symptom-${symptom}`}
                              checked={formData.symptoms.includes(symptom)}
                              onCheckedChange={(checked) => handleSymptomChange(symptom, checked as boolean)}
                              data-testid={`symptom-checkbox-${symptom.toLowerCase().replace(' ', '-')}`}
                            />
                            <Label htmlFor={`symptom-${symptom}`} className="text-sm">
                              {symptom}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Severity Level */}
                    <div className="space-y-2">
                      <Label>Overall severity (1-10)</Label>
                      <Select 
                        value={formData.severityLevel.toString()} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, severityLevel: parseInt(value) }))}
                      >
                        <SelectTrigger data-testid="severity-select">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 10 }, (_, i) => i + 1).map((level) => (
                            <SelectItem key={level} value={level.toString()}>
                              {level} - {level <= 3 ? 'Mild' : level <= 6 ? 'Moderate' : level <= 8 ? 'Severe' : 'Critical'}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Water Consumption */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="water-consumption">Water consumed (liters)</Label>
                        <Input
                          id="water-consumption"
                          type="number"
                          placeholder="e.g., 2.5"
                          value={formData.waterConsumption}
                          onChange={(e) => setFormData(prev => ({ ...prev, waterConsumption: e.target.value }))}
                          data-testid="water-consumption-input"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="water-source">Water source</Label>
                        <Select 
                          value={formData.waterSource} 
                          onValueChange={(value) => setFormData(prev => ({ ...prev, waterSource: value }))}
                        >
                          <SelectTrigger data-testid="water-source-select">
                            <SelectValue placeholder="Select source" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="bottled">Bottled water</SelectItem>
                            <SelectItem value="boiled">Boiled tap water</SelectItem>
                            <SelectItem value="filtered">Filtered water</SelectItem>
                            <SelectItem value="tap">Direct tap water</SelectItem>
                            <SelectItem value="well">Well water</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Additional Fields */}
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="food-intake">Food intake</Label>
                        <Textarea
                          id="food-intake"
                          placeholder="Describe what you ate today..."
                          value={formData.foodIntake}
                          onChange={(e) => setFormData(prev => ({ ...prev, foodIntake: e.target.value }))}
                          data-testid="food-intake-textarea"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="activities">Activities & exercise</Label>
                        <Textarea
                          id="activities"
                          placeholder="Describe your activities today..."
                          value={formData.activities}
                          onChange={(e) => setFormData(prev => ({ ...prev, activities: e.target.value }))}
                          data-testid="activities-textarea"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="mood">Mood</Label>
                        <Select 
                          value={formData.mood} 
                          onValueChange={(value) => setFormData(prev => ({ ...prev, mood: value }))}
                        >
                          <SelectTrigger data-testid="mood-select">
                            <SelectValue placeholder="How are you feeling?" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="excellent">Excellent</SelectItem>
                            <SelectItem value="good">Good</SelectItem>
                            <SelectItem value="okay">Okay</SelectItem>
                            <SelectItem value="poor">Poor</SelectItem>
                            <SelectItem value="terrible">Terrible</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="notes">Additional notes</Label>
                        <Textarea
                          id="notes"
                          placeholder="Any other observations or notes..."
                          value={formData.notes}
                          onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                          data-testid="notes-textarea"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="location">Location</Label>
                        <Input
                          id="location"
                          placeholder="e.g., Guwahati, Assam"
                          value={formData.location}
                          onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                          data-testid="location-input"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end space-x-2 pt-4 border-t">
                      <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                        Cancel
                      </Button>
                      <Button 
                        onClick={() => addEntryMutation.mutate(formData)}
                        disabled={addEntryMutation.isPending}
                        data-testid="save-entry-button"
                      >
                        {addEntryMutation.isPending ? "Saving..." : "Save Entry"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{entries?.length || 0}</div>
                <div className="text-sm text-muted-foreground">Total Entries</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-accent">
                  {entries?.filter(e => e.symptoms.length > 0).length || 0}
                </div>
                <div className="text-sm text-muted-foreground">Days with Symptoms</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-secondary">
                  {entries?.length > 0 ? 
                    Math.round(entries.reduce((sum, e) => sum + (e.severityLevel || 0), 0) / entries.length) : 0
                  }
                </div>
                <div className="text-sm text-muted-foreground">Avg Severity</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Entries Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {entries?.map((entry) => (
            <Card key={entry.id} className="hover:shadow-md transition-shadow" data-testid={`diary-entry-${entry.id}`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <CalendarIcon className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">
                      {format(new Date(entry.date), "MMM dd, yyyy")}
                    </span>
                  </div>
                  {entry.severityLevel && (
                    <Badge className={getSeverityColor(entry.severityLevel)}>
                      {entry.severityLevel}/10
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Symptoms */}
                {entry.symptoms.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-1">Symptoms:</h4>
                    <div className="flex flex-wrap gap-1">
                      {entry.symptoms.slice(0, 3).map((symptom, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {symptom}
                        </Badge>
                      ))}
                      {entry.symptoms.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{entry.symptoms.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>
                )}

                {/* Water Consumption */}
                {entry.waterConsumption && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">Water: </span>
                    <span className="font-medium">{entry.waterConsumption}L</span>
                    {entry.waterSource && (
                      <span className="text-muted-foreground"> ({entry.waterSource})</span>
                    )}
                  </div>
                )}

                {/* Mood */}
                {entry.mood && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">Mood: </span>
                    <span className="font-medium capitalize">{entry.mood}</span>
                  </div>
                )}

                {/* Notes Preview */}
                {entry.notes && (
                  <div className="text-sm">
                    <p className="text-muted-foreground line-clamp-2">{entry.notes}</p>
                  </div>
                )}

                {/* Location */}
                {entry.location && (
                  <div className="text-xs text-muted-foreground">
                    📍 {entry.location}
                  </div>
                )}
              </CardContent>
            </Card>
          )) || (
            <div className="col-span-full text-center py-12">
              <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No diary entries yet. Start tracking your health!</p>
            </div>
          )}
        </div>

        {/* Health Trends */}
        {entries && entries.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                <span>Health Insights</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">Common Symptoms</h4>
                  <div className="space-y-1">
                    {Array.from(new Set(entries.flatMap(e => e.symptoms))).slice(0, 5).map((symptom) => {
                      const count = entries.filter(e => e.symptoms.includes(symptom)).length;
                      return (
                        <div key={symptom} className="flex justify-between text-sm">
                          <span className="text-muted-foreground">{symptom}</span>
                          <span className="font-medium">{count} times</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Water Consumption Avg</h4>
                  <div className="space-y-1">
                    <div className="text-2xl font-bold text-primary">
                      {entries.filter(e => e.waterConsumption).length > 0 ? 
                        (entries
                          .filter(e => e.waterConsumption)
                          .reduce((sum, e) => sum + parseFloat(e.waterConsumption || "0"), 0) / 
                         entries.filter(e => e.waterConsumption).length
                        ).toFixed(1) : "0"
                      }L
                    </div>
                    <div className="text-sm text-muted-foreground">per day</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
