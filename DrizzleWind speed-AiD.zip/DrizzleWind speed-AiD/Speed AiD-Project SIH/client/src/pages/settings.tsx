import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Settings as SettingsIcon, User as UserIcon, Bell, MapPin, Shield, Smartphone } from "lucide-react";
import type { User } from "@/lib/types";

const MOCK_USER_ID = "user-123"; // In a real app, this would come from auth context

export default function Settings() {
  const [activeTab, setActiveTab] = useState("profile");
  const [profileData, setProfileData] = useState({
    firstName: "Sarah",
    lastName: "Johnson",
    email: "sarah.johnson@example.com",
    phone: "+91-9876543210",
    location: "Guwahati, Assam",
  });

  const [notificationSettings, setNotificationSettings] = useState({
    sms: true,
    email: true,
    whatsapp: false,
    push: true,
    emergencyAlerts: true,
    healthReminders: true,
    appointmentReminders: true,
    weatherUpdates: false,
  });

  const [locationSettings, setLocationSettings] = useState({
    shareLocation: true,
    autoDetect: false,
    radius: "10",
  });

  const { toast } = useToast();

  const { data: user } = useQuery<User>({
    queryKey: ["/api/users", MOCK_USER_ID],
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("PUT", `/api/users/${MOCK_USER_ID}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your profile information has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "There was an error updating your profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const tabs = [
    { id: "profile", label: "Profile", icon: UserIcon },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "location", label: "Location", icon: MapPin },
    { id: "privacy", label: "Privacy & Security", icon: Shield },
  ];

  const handleSaveProfile = () => {
    updateProfileMutation.mutate(profileData);
  };

  const handleSaveNotifications = () => {
    updateProfileMutation.mutate({ 
      notificationPreferences: notificationSettings 
    });
  };

  return (
    <MainLayout title="Settings" subtitle="Manage your account and preferences">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Tab Navigation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <SettingsIcon className="w-5 h-5 text-primary" />
              <span>Account Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <Button
                    key={tab.id}
                    variant={activeTab === tab.id ? "default" : "outline"}
                    onClick={() => setActiveTab(tab.id)}
                    className="flex items-center space-x-2"
                    data-testid={`tab-${tab.id}`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Profile Tab */}
        {activeTab === "profile" && (
          <Card data-testid="profile-settings">
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={profileData.firstName}
                    onChange={(e) => setProfileData(prev => ({ ...prev, firstName: e.target.value }))}
                    data-testid="first-name-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={profileData.lastName}
                    onChange={(e) => setProfileData(prev => ({ ...prev, lastName: e.target.value }))}
                    data-testid="last-name-input"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={profileData.email}
                  onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                  data-testid="email-input"
                />
                <p className="text-xs text-muted-foreground">
                  This email will be used for health alerts and appointment confirmations.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={profileData.phone}
                  onChange={(e) => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                  data-testid="phone-input"
                />
                <p className="text-xs text-muted-foreground">
                  Required for SMS emergency alerts and appointment reminders.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Current Location</Label>
                <Input
                  id="location"
                  value={profileData.location}
                  onChange={(e) => setProfileData(prev => ({ ...prev, location: e.target.value }))}
                  placeholder="City, State"
                  data-testid="location-input"
                />
                <p className="text-xs text-muted-foreground">
                  Used for location-based health alerts and finding nearby hospitals.
                </p>
              </div>

              <Button 
                onClick={handleSaveProfile}
                disabled={updateProfileMutation.isPending}
                data-testid="save-profile-button"
              >
                {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Notifications Tab */}
        {activeTab === "notifications" && (
          <Card data-testid="notification-settings">
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Communication Channels */}
              <div>
                <h3 className="font-medium text-foreground mb-4">Communication Channels</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Smartphone className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <Label htmlFor="sms">SMS Notifications</Label>
                        <p className="text-sm text-muted-foreground">Emergency alerts and critical updates</p>
                      </div>
                    </div>
                    <Switch
                      id="sms"
                      checked={notificationSettings.sms}
                      onCheckedChange={(checked) => 
                        setNotificationSettings(prev => ({ ...prev, sms: checked }))
                      }
                      data-testid="sms-toggle"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Bell className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <Label htmlFor="email">Email Notifications</Label>
                        <p className="text-sm text-muted-foreground">Detailed reports and reminders</p>
                      </div>
                    </div>
                    <Switch
                      id="email"
                      checked={notificationSettings.email}
                      onCheckedChange={(checked) => 
                        setNotificationSettings(prev => ({ ...prev, email: checked }))
                      }
                      data-testid="email-toggle"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Smartphone className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <Label htmlFor="whatsapp">WhatsApp Messages</Label>
                        <p className="text-sm text-muted-foreground">Community health updates</p>
                      </div>
                    </div>
                    <Switch
                      id="whatsapp"
                      checked={notificationSettings.whatsapp}
                      onCheckedChange={(checked) => 
                        setNotificationSettings(prev => ({ ...prev, whatsapp: checked }))
                      }
                      data-testid="whatsapp-toggle"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Bell className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <Label htmlFor="push">Push Notifications</Label>
                        <p className="text-sm text-muted-foreground">Real-time web notifications</p>
                      </div>
                    </div>
                    <Switch
                      id="push"
                      checked={notificationSettings.push}
                      onCheckedChange={(checked) => 
                        setNotificationSettings(prev => ({ ...prev, push: checked }))
                      }
                      data-testid="push-toggle"
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Alert Types */}
              <div>
                <h3 className="font-medium text-foreground mb-4">Alert Types</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="emergencyAlerts">Emergency Health Alerts</Label>
                      <p className="text-sm text-muted-foreground">Critical disease outbreaks and emergencies</p>
                    </div>
                    <Switch
                      id="emergencyAlerts"
                      checked={notificationSettings.emergencyAlerts}
                      onCheckedChange={(checked) => 
                        setNotificationSettings(prev => ({ ...prev, emergencyAlerts: checked }))
                      }
                      data-testid="emergency-alerts-toggle"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="healthReminders">Health Reminders</Label>
                      <p className="text-sm text-muted-foreground">Medication and health check reminders</p>
                    </div>
                    <Switch
                      id="healthReminders"
                      checked={notificationSettings.healthReminders}
                      onCheckedChange={(checked) => 
                        setNotificationSettings(prev => ({ ...prev, healthReminders: checked }))
                      }
                      data-testid="health-reminders-toggle"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="appointmentReminders">Appointment Reminders</Label>
                      <p className="text-sm text-muted-foreground">Upcoming medical appointments</p>
                    </div>
                    <Switch
                      id="appointmentReminders"
                      checked={notificationSettings.appointmentReminders}
                      onCheckedChange={(checked) => 
                        setNotificationSettings(prev => ({ ...prev, appointmentReminders: checked }))
                      }
                      data-testid="appointment-reminders-toggle"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="weatherUpdates">Weather Updates</Label>
                      <p className="text-sm text-muted-foreground">Weather conditions affecting health risks</p>
                    </div>
                    <Switch
                      id="weatherUpdates"
                      checked={notificationSettings.weatherUpdates}
                      onCheckedChange={(checked) => 
                        setNotificationSettings(prev => ({ ...prev, weatherUpdates: checked }))
                      }
                      data-testid="weather-updates-toggle"
                    />
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleSaveNotifications}
                disabled={updateProfileMutation.isPending}
                data-testid="save-notifications-button"
              >
                {updateProfileMutation.isPending ? "Saving..." : "Save Notification Settings"}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Location Tab */}
        {activeTab === "location" && (
          <Card data-testid="location-settings">
            <CardHeader>
              <CardTitle>Location & Privacy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="shareLocation">Share Location</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow SPEED AiD to access your location for personalized health alerts
                    </p>
                  </div>
                  <Switch
                    id="shareLocation"
                    checked={locationSettings.shareLocation}
                    onCheckedChange={(checked) => 
                      setLocationSettings(prev => ({ ...prev, shareLocation: checked }))
                    }
                    data-testid="share-location-toggle"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="autoDetect">Auto-detect Location</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically update location based on device GPS
                    </p>
                  </div>
                  <Switch
                    id="autoDetect"
                    checked={locationSettings.autoDetect}
                    onCheckedChange={(checked) => 
                      setLocationSettings(prev => ({ ...prev, autoDetect: checked }))
                    }
                    data-testid="auto-detect-toggle"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="alertRadius">Alert Radius</Label>
                  <Select 
                    value={locationSettings.radius} 
                    onValueChange={(value) => 
                      setLocationSettings(prev => ({ ...prev, radius: value }))
                    }
                  >
                    <SelectTrigger data-testid="alert-radius-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 km</SelectItem>
                      <SelectItem value="10">10 km</SelectItem>
                      <SelectItem value="25">25 km</SelectItem>
                      <SelectItem value="50">50 km</SelectItem>
                      <SelectItem value="100">100 km</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Receive alerts for health risks within this distance from your location
                  </p>
                </div>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-medium text-foreground mb-2">Location Privacy</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Your exact location is never shared with other users</li>
                  <li>• Location data is used only for relevant health alerts</li>
                  <li>• You can disable location sharing at any time</li>
                  <li>• Data is encrypted and stored securely</li>
                </ul>
              </div>

              <Button 
                onClick={() => {
                  updateProfileMutation.mutate(locationSettings);
                }}
                disabled={updateProfileMutation.isPending}
                data-testid="save-location-button"
              >
                {updateProfileMutation.isPending ? "Saving..." : "Save Location Settings"}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Privacy Tab */}
        {activeTab === "privacy" && (
          <Card data-testid="privacy-settings">
            <CardHeader>
              <CardTitle>Privacy & Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-medium text-foreground mb-4">Account Security</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">Change Password</p>
                      <p className="text-sm text-muted-foreground">Update your account password</p>
                    </div>
                    <Button variant="outline" data-testid="change-password-button">
                      Change
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">Two-Factor Authentication</p>
                      <p className="text-sm text-muted-foreground">Add extra security to your account</p>
                    </div>
                    <Button variant="outline" data-testid="enable-2fa-button">
                      Enable
                    </Button>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium text-foreground mb-4">Data & Privacy</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">Download Your Data</p>
                      <p className="text-sm text-muted-foreground">Get a copy of your health diary and settings</p>
                    </div>
                    <Button variant="outline" data-testid="download-data-button">
                      Download
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">Delete Account</p>
                      <p className="text-sm text-muted-foreground">Permanently remove your account and data</p>
                    </div>
                    <Button variant="destructive" data-testid="delete-account-button">
                      Delete
                    </Button>
                  </div>
                </div>
              </div>

              <div className="bg-primary/10 p-4 rounded-lg">
                <h4 className="font-medium text-foreground mb-2">Privacy Policy</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  We are committed to protecting your privacy and health data. Learn more about how we collect, 
                  use, and protect your information.
                </p>
                <Button variant="link" className="p-0 h-auto text-primary">
                  Read Full Privacy Policy
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Help & Support */}
        <Card>
          <CardHeader>
            <CardTitle>Help & Support</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-foreground mb-2">Contact Support</h3>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>📧 support@speedaid.org</p>
                  <p>📞 +91-1234567890</p>
                  <p>🕐 Mon-Fri, 9 AM - 6 PM IST</p>
                </div>
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-2">Emergency Contacts</h3>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>🚨 Emergency Services: 108</p>
                  <p>🏥 Health Helpline: 104</p>
                  <p>☎️ SPEED AiD Emergency: 1800-123-4567</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
