import { useQuery } from "@tanstack/react-query";
import MainLayout from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { MapPin, Layers, Filter, RefreshCw } from "lucide-react";
import { useState } from "react";
import type { DiseaseCase, RiskArea } from "@/lib/types";

export default function RiskMap() {
  const [selectedLayer, setSelectedLayer] = useState("all");
  const [timeFilter, setTimeFilter] = useState("7");

  const { data: diseaseCases, isLoading: casesLoading, refetch } = useQuery<DiseaseCase[]>({
    queryKey: ["/api/disease-cases"],
  });

  const { data: riskAreas, isLoading: areasLoading } = useQuery<RiskArea[]>({
    queryKey: ["/api/risk-areas"],
  });

  const isLoading = casesLoading || areasLoading;

  const getRiskColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'critical': return 'bg-destructive text-destructive-foreground';
      case 'high': return 'bg-accent text-accent-foreground';
      case 'medium': return 'bg-chart-4 text-foreground';
      case 'low': return 'bg-secondary text-secondary-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  if (isLoading) {
    return (
      <MainLayout 
        title="Risk Assessment Map" 
        subtitle="Geographic visualization of waterborne disease risks"
      >
        <Skeleton className="h-96 w-full" />
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      title="Risk Assessment Map" 
      subtitle="Geographic visualization of waterborne disease risks"
    >
      <div className="space-y-6">
        {/* Map Controls */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="w-5 h-5" />
                <span>Interactive Risk Map</span>
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Select value={selectedLayer} onValueChange={setSelectedLayer}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Layers</SelectItem>
                    <SelectItem value="cases">Disease Cases</SelectItem>
                    <SelectItem value="risk">Risk Areas</SelectItem>
                    <SelectItem value="water">Water Quality</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={timeFilter} onValueChange={setTimeFilter}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 3 months</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={() => refetch()}>
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-96 bg-muted rounded-lg relative overflow-hidden" data-testid="risk-map-container">
              {/* Enhanced map visualization */}
              <img 
                src="https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600" 
                alt="Northeast India detailed map"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10"></div>
              
              {/* Risk Area Overlays */}
              {riskAreas?.map((area, index) => (
                <div
                  key={area.id}
                  className={`absolute rounded-full opacity-60 ${getRiskColor(area.riskLevel).replace('text-', 'border-').replace('bg-', 'border-')}`}
                  style={{
                    width: `${Math.max(parseFloat(area.radius) * 2, 30)}px`,
                    height: `${Math.max(parseFloat(area.radius) * 2, 30)}px`,
                    top: `${20 + (index % 3) * 30}%`,
                    left: `${25 + (index % 4) * 20}%`,
                    border: '3px solid',
                  }}
                  title={`${area.name} - ${area.riskLevel} risk`}
                  data-testid={`risk-area-${index}`}
                />
              ))}

              {/* Disease Case Markers */}
              {diseaseCases?.slice(0, 15).map((caseItem, index) => (
                <div
                  key={caseItem.id}
                  className={`absolute w-3 h-3 rounded-full cursor-pointer ${getRiskColor(caseItem.severity)} animate-pulse`}
                  style={{
                    top: `${30 + (index % 5) * 15}%`,
                    left: `${35 + (index % 6) * 10}%`,
                  }}
                  title={`${caseItem.location} - ${caseItem.status}`}
                  data-testid={`case-marker-${index}`}
                />
              ))}

              {/* Enhanced Legend */}
              <div className="absolute bottom-4 left-4 bg-card/95 backdrop-blur-sm rounded-lg p-4 space-y-3 min-w-48">
                <h4 className="font-medium text-foreground text-sm">Map Legend</h4>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-4 h-4 bg-destructive rounded border-2 border-destructive opacity-60"></div>
                    <span>Critical Risk Areas</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-4 h-4 bg-accent rounded border-2 border-accent opacity-60"></div>
                    <span>High Risk Areas</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-3 h-3 bg-destructive rounded-full"></div>
                    <span>Disease Cases</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-3 h-3 bg-primary rounded-full"></div>
                    <span>Water Monitoring</span>
                  </div>
                </div>
              </div>

              {/* Map Statistics */}
              <div className="absolute top-4 right-4 bg-card/95 backdrop-blur-sm rounded-lg p-3">
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Active Cases:</span>
                    <span className="font-medium">{diseaseCases?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Risk Areas:</span>
                    <span className="font-medium">{riskAreas?.length || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Areas Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>High-Risk Areas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {riskAreas?.filter(area => area.riskLevel === 'high' || area.riskLevel === 'critical')
                  .slice(0, 5).map((area) => (
                  <div key={area.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">{area.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Population: {area.population?.toLocaleString() || 'Unknown'}
                      </p>
                    </div>
                    <Badge className={getRiskColor(area.riskLevel)}>
                      {area.riskLevel}
                    </Badge>
                  </div>
                )) || (
                  <p className="text-muted-foreground">No high-risk areas currently identified</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Disease Cases</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {diseaseCases?.slice(0, 5).map((caseItem) => (
                  <div key={caseItem.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">{caseItem.location}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(caseItem.reportedDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge className={getRiskColor(caseItem.severity)}>
                        {caseItem.severity}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        {caseItem.status}
                      </p>
                    </div>
                  </div>
                )) || (
                  <p className="text-muted-foreground">No recent disease cases</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
