import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import MainLayout from "@/components/layout/main-layout";
import AlertCenter from "@/components/alerts/alert-center";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { EmergencyAlertDialog } from "@/components/communication/emergency-alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Bell, AlertTriangle, Info, Plus, Filter } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { Notification } from "@/lib/types";

const MOCK_USER_ID = "user-123"; // In a real app, this would come from auth context

export default function Alerts() {
  const [showEmergencyDialog, setShowEmergencyDialog] = useState(false);
  const [typeFilter, setTypeFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: notifications, isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });

  const filteredNotifications = notifications?.filter((notification) => {
    const matchesType = typeFilter === "all" || notification.type === typeFilter;
    const matchesPriority = priorityFilter === "all" || notification.priority === priorityFilter;
    const matchesStatus = statusFilter === "all" || notification.status === statusFilter;
    
    return matchesType && matchesPriority && matchesStatus;
  }) || [];

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'emergency':
      case 'alert':
        return AlertTriangle;
      case 'info':
        return Info;
      default:
        return Bell;
    }
  };

  const getAlertColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'border-destructive bg-destructive/10 text-destructive';
      case 'high':
        return 'border-accent bg-accent/10 text-accent';
      case 'medium':
        return 'border-primary bg-primary/10 text-primary';
      default:
        return 'border-border bg-muted text-muted-foreground';
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'bg-destructive text-destructive-foreground';
      case 'high':
        return 'bg-accent text-accent-foreground';
      case 'medium':
        return 'bg-primary text-primary-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'delivered':
        return 'bg-secondary text-secondary-foreground';
      case 'sent':
        return 'bg-primary text-primary-foreground';
      case 'failed':
        return 'bg-destructive text-destructive-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  if (isLoading) {
    return (
      <MainLayout title="Alerts & Notifications" subtitle="Manage health alerts and emergency notifications">
        <div className="space-y-6">
          <Skeleton className="h-32 w-full" />
          <div className="space-y-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Alerts & Notifications" subtitle="Manage health alerts and emergency notifications">
      <div className="space-y-6">
        {/* Control Panel */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <Bell className="w-5 h-5 text-primary" />
                <span>Alert Management</span>
              </CardTitle>
              <Dialog open={showEmergencyDialog} onOpenChange={setShowEmergencyDialog}>
                <DialogTrigger asChild>
                  <Button variant="destructive" data-testid="create-emergency-alert">
                    <Plus className="w-4 h-4 mr-2" />
                    Send Emergency Alert
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Send Emergency Alert</DialogTitle>
                  </DialogHeader>
                  <EmergencyAlertDialog onClose={() => setShowEmergencyDialog(false)} />
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {/* Filters */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger data-testid="type-filter">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="emergency">Emergency</SelectItem>
                  <SelectItem value="alert">Health Alert</SelectItem>
                  <SelectItem value="reminder">Reminder</SelectItem>
                  <SelectItem value="info">Information</SelectItem>
                </SelectContent>
              </Select>

              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger data-testid="priority-filter">
                  <SelectValue placeholder="All Priorities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priorities</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger data-testid="status-filter">
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>

              <Button 
                variant="outline"
                onClick={() => {
                  setTypeFilter("all");
                  setPriorityFilter("all");
                  setStatusFilter("all");
                }}
                data-testid="clear-filters"
              >
                <Filter className="w-4 h-4 mr-2" />
                Clear Filters
              </Button>
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center p-3 bg-destructive/10 rounded-lg">
                <div className="text-2xl font-bold text-destructive">
                  {notifications?.filter(n => n.priority === 'critical').length || 0}
                </div>
                <div className="text-sm text-muted-foreground">Critical Alerts</div>
              </div>
              <div className="text-center p-3 bg-accent/10 rounded-lg">
                <div className="text-2xl font-bold text-accent">
                  {notifications?.filter(n => n.priority === 'high').length || 0}
                </div>
                <div className="text-sm text-muted-foreground">High Priority</div>
              </div>
              <div className="text-center p-3 bg-secondary/10 rounded-lg">
                <div className="text-2xl font-bold text-secondary">
                  {notifications?.filter(n => n.status === 'delivered').length || 0}
                </div>
                <div className="text-sm text-muted-foreground">Delivered</div>
              </div>
              <div className="text-center p-3 bg-primary/10 rounded-lg">
                <div className="text-2xl font-bold text-primary">
                  {notifications?.filter(n => n.type === 'emergency').length || 0}
                </div>
                <div className="text-sm text-muted-foreground">Emergency</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Alert Center Component */}
        <AlertCenter />

        {/* Notifications List */}
        <Card>
          <CardHeader>
            <CardTitle>All Notifications ({filteredNotifications.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {filteredNotifications.map((notification) => {
                const Icon = getAlertIcon(notification.type);
                return (
                  <div
                    key={notification.id}
                    className={`p-4 rounded-lg border ${getAlertColor(notification.priority)}`}
                    data-testid={`notification-${notification.id}`}
                  >
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0">
                        <Icon className="w-5 h-5 mt-1" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium text-foreground">{notification.title}</h3>
                          <div className="flex space-x-2">
                            <Badge className={getPriorityBadge(notification.priority)}>
                              {notification.priority}
                            </Badge>
                            <Badge className={getStatusBadge(notification.status)}>
                              {notification.status}
                            </Badge>
                          </div>
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-3">
                          {notification.message}
                        </p>

                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <div className="flex items-center space-x-4">
                            <span>
                              {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                            </span>
                            <span>
                              Channels: {notification.channels.join(', ')}
                            </span>
                            <span>
                              Target: {notification.targetAudience}
                            </span>
                          </div>
                          {notification.sentAt && (
                            <span>
                              Sent: {formatDistanceToNow(new Date(notification.sentAt), { addSuffix: true })}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}

              {filteredNotifications.length === 0 && (
                <div className="text-center py-8">
                  <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    {typeFilter !== "all" || priorityFilter !== "all" || statusFilter !== "all"
                      ? "No notifications match your filters."
                      : "No notifications available."}
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Communication Channels Status */}
        <Card>
          <CardHeader>
            <CardTitle>Communication Channels</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-muted rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">SMS (Twilio)</h4>
                  <Badge className="bg-secondary text-secondary-foreground">Active</Badge>
                </div>
                <p className="text-sm text-muted-foreground">Emergency notifications via SMS</p>
                <div className="mt-2 text-xs text-muted-foreground">
                  Last used: 2 hours ago
                </div>
              </div>

              <div className="p-4 bg-muted rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">Email (SendGrid)</h4>
                  <Badge className="bg-secondary text-secondary-foreground">Active</Badge>
                </div>
                <p className="text-sm text-muted-foreground">Detailed health reports and updates</p>
                <div className="mt-2 text-xs text-muted-foreground">
                  Last used: 1 hour ago
                </div>
              </div>

              <div className="p-4 bg-muted rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">WhatsApp Business</h4>
                  <Badge className="bg-secondary text-secondary-foreground">Active</Badge>
                </div>
                <p className="text-sm text-muted-foreground">Community health messaging</p>
                <div className="mt-2 text-xs text-muted-foreground">
                  Last used: 30 minutes ago
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
