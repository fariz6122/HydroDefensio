import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import MainLayout from "@/components/layout/main-layout";
import HospitalCard from "@/components/hospitals/hospital-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Hospital as HospitalIcon, Search, MapPin, Filter, Phone } from "lucide-react";
import type { Hospital } from "@/lib/types";

export default function Hospitals() {
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");
  const [servicesFilter, setServicesFilter] = useState("all");

  const { data: hospitals, isLoading } = useQuery<Hospital[]>({
    queryKey: ["/api/hospitals"],
  });

  const filteredHospitals = hospitals?.filter((hospital) => {
    const matchesSearch = hospital.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         hospital.address.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === "all" || hospital.type === typeFilter;
    const matchesLocation = locationFilter === "all" || 
                           hospital.address.toLowerCase().includes(locationFilter.toLowerCase());
    const matchesServices = servicesFilter === "all" || 
                           (servicesFilter === "emergency" && hospital.emergencyServices) ||
                           hospital.services.some(service => 
                             service.toLowerCase().includes(servicesFilter.toLowerCase())
                           );

    return matchesSearch && matchesType && matchesLocation && matchesServices;
  }) || [];

  const hospitalTypes = Array.from(new Set(hospitals?.map(h => h.type) || []));
  const locations = Array.from(new Set(hospitals?.map(h => {
    const parts = h.address.split(',');
    return parts[parts.length - 1]?.trim() || 'Unknown';
  }) || []));

  if (isLoading) {
    return (
      <MainLayout title="Healthcare Facilities" subtitle="Find hospitals and clinics in your area">
        <div className="space-y-6">
          <Skeleton className="h-32 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-80 w-full" />
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Healthcare Facilities" subtitle="Find hospitals and clinics in your area">
      <div className="space-y-6">
        {/* Search and Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <HospitalIcon className="w-5 h-5 text-primary" />
              <span>Find Healthcare Facilities</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search hospitals, clinics, or addresses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="hospital-search"
              />
            </div>

            {/* Filters */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger data-testid="type-filter">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {hospitalTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type.charAt(0).toUpperCase() + type.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={locationFilter} onValueChange={setLocationFilter}>
                <SelectTrigger data-testid="location-filter">
                  <SelectValue placeholder="All Locations" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  {locations.map((location) => (
                    <SelectItem key={location} value={location}>
                      {location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={servicesFilter} onValueChange={setServicesFilter}>
                <SelectTrigger data-testid="services-filter">
                  <SelectValue placeholder="All Services" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Services</SelectItem>
                  <SelectItem value="emergency">Emergency Services</SelectItem>
                  <SelectItem value="gastroenterology">Gastroenterology</SelectItem>
                  <SelectItem value="infectious">Infectious Disease</SelectItem>
                  <SelectItem value="pediatrics">Pediatrics</SelectItem>
                  <SelectItem value="general">General Medicine</SelectItem>
                </SelectContent>
              </Select>

              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchQuery("");
                  setTypeFilter("all");
                  setLocationFilter("all");
                  setServicesFilter("all");
                }}
                data-testid="clear-filters"
              >
                <Filter className="w-4 h-4 mr-2" />
                Clear Filters
              </Button>
            </div>

            {/* Results Summary */}
            <div className="flex items-center justify-between pt-2 border-t">
              <p className="text-sm text-muted-foreground">
                Found {filteredHospitals.length} healthcare facilities
              </p>
              <div className="flex space-x-2">
                <Badge variant="outline" className="bg-secondary text-secondary-foreground">
                  {hospitals?.filter(h => h.emergencyServices).length || 0} with Emergency
                </Badge>
                <Badge variant="outline" className="bg-primary text-primary-foreground">
                  {hospitals?.filter(h => h.isActive).length || 0} Active
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Banner */}
        <Card className="border-destructive bg-destructive/10">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-destructive rounded-lg flex items-center justify-center">
                <Phone className="w-5 h-5 text-destructive-foreground" />
              </div>
              <div>
                <p className="font-medium text-foreground">Medical Emergency?</p>
                <p className="text-sm text-muted-foreground">
                  For life-threatening emergencies, call 108 immediately or visit the nearest emergency room
                </p>
              </div>
              <Button variant="destructive" className="ml-auto">
                Call 108
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Hospitals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredHospitals.map((hospital) => (
            <HospitalCard key={hospital.id} hospital={hospital} />
          ))}
        </div>

        {/* Empty State */}
        {filteredHospitals.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <HospitalIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">
                {searchQuery || typeFilter !== "all" || locationFilter !== "all" || servicesFilter !== "all"
                  ? "No hospitals match your search criteria."
                  : "No healthcare facilities available."}
              </p>
              {(searchQuery || typeFilter !== "all" || locationFilter !== "all" || servicesFilter !== "all") && (
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchQuery("");
                    setTypeFilter("all");
                    setLocationFilter("all");
                    setServicesFilter("all");
                  }}
                >
                  Clear All Filters
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* Quick Stats */}
        {hospitals && hospitals.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Healthcare Network Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{hospitals.length}</div>
                  <div className="text-sm text-muted-foreground">Total Facilities</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-secondary">
                    {hospitals.filter(h => h.emergencyServices).length}
                  </div>
                  <div className="text-sm text-muted-foreground">Emergency Services</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent">
                    {hospitals.filter(h => h.type === 'government').length}
                  </div>
                  <div className="text-sm text-muted-foreground">Government</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-chart-4">
                    {Math.round(
                      hospitals.reduce((sum, h) => sum + (h.currentOccupancy || 0), 0) / 
                      hospitals.reduce((sum, h) => sum + (h.capacity || 1), 0) * 100
                    )}%
                  </div>
                  <div className="text-sm text-muted-foreground">Avg Occupancy</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
