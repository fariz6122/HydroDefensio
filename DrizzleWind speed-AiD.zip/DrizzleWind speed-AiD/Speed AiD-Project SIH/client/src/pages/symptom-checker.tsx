import { useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import AssessmentForm from "@/components/symptom-checker/assessment-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Stethoscope, AlertTriangle, Info } from "lucide-react";

export default function SymptomChecker() {
  const [showDisclaimer, setShowDisclaimer] = useState(true);

  return (
    <MainLayout 
      title="Symptom Checker" 
      subtitle="AI-powered health assessment for waterborne disease symptoms"
    >
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Medical Disclaimer */}
        {showDisclaimer && (
          <Alert className="border-accent bg-accent/10">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Medical Disclaimer:</strong> This symptom checker is for informational purposes only and should not replace professional medical advice. 
              If you are experiencing severe symptoms or a medical emergency, please seek immediate medical attention or call emergency services.
            </AlertDescription>
          </Alert>
        )}

        {/* Information Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Stethoscope className="w-5 h-5 text-primary" />
              <span>Waterborne Disease Assessment</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-foreground mb-2">How it works:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Answer questions about your symptoms</li>
                  <li>• Provide duration and severity information</li>
                  <li>• Get instant risk assessment</li>
                  <li>• Receive personalized recommendations</li>
                </ul>
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-2">Common waterborne diseases:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Cholera</li>
                  <li>• Typhoid fever</li>
                  <li>• Hepatitis A</li>
                  <li>• E. coli infection</li>
                  <li>• Giardiasis</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Assessment Form */}
        <AssessmentForm />

        {/* When to Seek Immediate Care */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-destructive">
              <AlertTriangle className="w-5 h-5" />
              <span>When to Seek Immediate Medical Care</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-destructive/10 p-4 rounded-lg">
              <p className="font-medium text-foreground mb-2">Call emergency services or go to the nearest hospital immediately if you experience:</p>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Severe dehydration (dizziness, dry mouth, little/no urination)</li>
                <li>• Blood in vomit or stool</li>
                <li>• High fever (over 102°F/39°C)</li>
                <li>• Severe abdominal pain</li>
                <li>• Signs of shock (rapid heartbeat, confusion, cold skin)</li>
                <li>• Difficulty breathing</li>
                <li>• Seizures or loss of consciousness</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Prevention Tips */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Info className="w-5 h-5 text-primary" />
              <span>Prevention Tips</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-foreground mb-2">Water Safety:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Drink only boiled, bottled, or treated water</li>
                  <li>• Avoid ice unless made from safe water</li>
                  <li>• Use bottled water for brushing teeth</li>
                  <li>• Check water quality reports regularly</li>
                </ul>
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-2">Food Safety:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Eat hot, thoroughly cooked food</li>
                  <li>• Avoid raw or undercooked seafood</li>
                  <li>• Wash fruits and vegetables with safe water</li>
                  <li>• Avoid street food and unpasteurized dairy</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
