import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import MainLayout from "@/components/layout/main-layout";
import AdminMetrics from "@/components/admin/admin-metrics";
import UserManagement from "@/components/admin/user-management";
import OutbreakManagement from "@/components/admin/outbreak-management";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Users, AlertTriangle, BarChart3, Settings, Database } from "lucide-react";
import type { User, DiseaseCase, Hospital, Notification } from "@/lib/types";

export default function AdminDashboard() {
  const [selectedMetric, setSelectedMetric] = useState("overview");

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: false, // Only enable for admin users
  });

  const { data: diseaseCases } = useQuery<DiseaseCase[]>({
    queryKey: ["/api/disease-cases"],
  });

  const { data: hospitals } = useQuery<Hospital[]>({
    queryKey: ["/api/hospitals"],
  });

  const { data: notifications } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });

  const systemStats = {
    totalUsers: users?.length || 0,
    activeCases: diseaseCases?.filter(c => c.status === 'confirmed').length || 0,
    totalHospitals: hospitals?.length || 0,
    alertsSent: notifications?.length || 0,
    criticalAlerts: notifications?.filter(n => n.priority === 'critical').length || 0,
    systemUptime: "99.9%",
    responseTime: "1.2s",
    dataProcessed: "2.4TB",
  };

  return (
    <MainLayout 
      title="System Administration" 
      subtitle="Monitor and manage the SPEED AiD disease monitoring system"
    >
      <div className="space-y-6">
        {/* Admin Header */}
        <Card className="border-accent bg-accent/5">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                  <Shield className="w-5 h-5 text-accent-foreground" />
                </div>
                <div>
                  <CardTitle className="text-xl">Administrator Dashboard</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    System-wide monitoring and management for Northeast India
                  </p>
                </div>
              </div>
              <Badge className="bg-secondary text-secondary-foreground">
                Admin Access
              </Badge>
            </div>
          </CardHeader>
        </Card>

        {/* System Overview Metrics */}
        <AdminMetrics stats={systemStats} />

        {/* Main Admin Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview" data-testid="overview-tab">
              <BarChart3 className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="users" data-testid="users-tab">
              <Users className="w-4 h-4 mr-2" />
              Users
            </TabsTrigger>
            <TabsTrigger value="outbreaks" data-testid="outbreaks-tab">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Outbreaks
            </TabsTrigger>
            <TabsTrigger value="hospitals" data-testid="hospitals-tab">
              <Shield className="w-4 h-4 mr-2" />
              Hospitals
            </TabsTrigger>
            <TabsTrigger value="alerts" data-testid="alerts-tab">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Alerts
            </TabsTrigger>
            <TabsTrigger value="system" data-testid="system-tab">
              <Settings className="w-4 h-4 mr-2" />
              System
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent System Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="flex items-center space-x-3 p-2 bg-muted rounded">
                        <div className="w-2 h-2 bg-primary rounded-full"></div>
                        <div className="flex-1 text-sm">
                          <p className="font-medium">
                            {i === 0 && "New cholera case reported in Guwahati"}
                            {i === 1 && "Emergency alert sent to 1,247 users"}
                            {i === 2 && "Water quality sensor offline in Silchar"}
                            {i === 3 && "Hospital capacity updated for GMCH"}
                            {i === 4 && "Weekly health report generated"}
                          </p>
                          <p className="text-muted-foreground">
                            {Math.floor(Math.random() * 60)} minutes ago
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* System Health */}
              <Card>
                <CardHeader>
                  <CardTitle>System Health Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Database Connection</span>
                      <Badge className="bg-secondary text-secondary-foreground">Healthy</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">SMS Service (Twilio)</span>
                      <Badge className="bg-secondary text-secondary-foreground">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Email Service (SendGrid)</span>
                      <Badge className="bg-secondary text-secondary-foreground">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">WhatsApp API</span>
                      <Badge className="bg-secondary text-secondary-foreground">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Weather API</span>
                      <Badge className="bg-secondary text-secondary-foreground">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Water Quality Sensors</span>
                      <Badge className="bg-accent text-accent-foreground">4 of 5 Online</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <UserManagement users={users || []} />
          </TabsContent>

          {/* Outbreaks Tab */}
          <TabsContent value="outbreaks">
            <OutbreakManagement cases={diseaseCases || []} />
          </TabsContent>

          {/* Hospitals Tab */}
          <TabsContent value="hospitals" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Hospital Network Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{hospitals?.length || 0}</div>
                    <div className="text-sm text-muted-foreground">Total Hospitals</div>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-secondary">
                      {hospitals?.filter(h => h.emergencyServices).length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Emergency Centers</div>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-accent">
                      {Math.round(
                        (hospitals?.reduce((sum, h) => sum + (h.currentOccupancy || 0), 0) || 0) /
                        (hospitals?.reduce((sum, h) => sum + (h.capacity || 1), 0) || 1) * 100
                      )}%
                    </div>
                    <div className="text-sm text-muted-foreground">Avg Occupancy</div>
                  </div>
                </div>

                <div className="mt-6">
                  <h4 className="font-medium mb-4">Hospital Status Overview</h4>
                  <div className="space-y-2">
                    {hospitals?.slice(0, 5).map((hospital) => (
                      <div key={hospital.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div>
                          <p className="font-medium text-sm">{hospital.name}</p>
                          <p className="text-xs text-muted-foreground">{hospital.address}</p>
                        </div>
                        <div className="text-right">
                          <Badge className={hospital.isActive ? "bg-secondary text-secondary-foreground" : "bg-muted text-muted-foreground"}>
                            {hospital.isActive ? "Active" : "Inactive"}
                          </Badge>
                          {hospital.capacity && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {hospital.currentOccupancy}/{hospital.capacity} beds
                            </p>
                          )}
                        </div>
                      </div>
                    )) || (
                      <p className="text-muted-foreground text-center py-4">No hospital data available</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Alert System Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div className="text-center p-4 bg-destructive/10 rounded-lg">
                    <div className="text-2xl font-bold text-destructive">
                      {notifications?.filter(n => n.priority === 'critical').length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Critical Alerts</div>
                  </div>
                  <div className="text-center p-4 bg-accent/10 rounded-lg">
                    <div className="text-2xl font-bold text-accent">
                      {notifications?.filter(n => n.priority === 'high').length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">High Priority</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/10 rounded-lg">
                    <div className="text-2xl font-bold text-secondary">
                      {notifications?.filter(n => n.status === 'delivered').length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Delivered</div>
                  </div>
                  <div className="text-center p-4 bg-primary/10 rounded-lg">
                    <div className="text-2xl font-bold text-primary">98.5%</div>
                    <div className="text-sm text-muted-foreground">Delivery Rate</div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-4">Recent Alerts</h4>
                  <div className="space-y-2">
                    {notifications?.slice(0, 5).map((notification) => (
                      <div key={notification.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div>
                          <p className="font-medium text-sm">{notification.title}</p>
                          <p className="text-xs text-muted-foreground">{notification.message}</p>
                        </div>
                        <div className="text-right">
                          <Badge className={
                            notification.priority === 'critical' ? "bg-destructive text-destructive-foreground" :
                            notification.priority === 'high' ? "bg-accent text-accent-foreground" :
                            "bg-primary text-primary-foreground"
                          }>
                            {notification.priority}
                          </Badge>
                          <p className="text-xs text-muted-foreground mt-1">
                            {notification.targetAudience} • {notification.channels.length} channels
                          </p>
                        </div>
                      </div>
                    )) || (
                      <p className="text-muted-foreground text-center py-4">No alerts available</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>System Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-4">API Integrations</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-muted rounded">
                        <span className="text-sm">Twilio SMS API</span>
                        <Button variant="outline" size="sm">Configure</Button>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-muted rounded">
                        <span className="text-sm">SendGrid Email API</span>
                        <Button variant="outline" size="sm">Configure</Button>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-muted rounded">
                        <span className="text-sm">WhatsApp Business API</span>
                        <Button variant="outline" size="sm">Configure</Button>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-muted rounded">
                        <span className="text-sm">OpenWeatherMap API</span>
                        <Button variant="outline" size="sm">Configure</Button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-4">Database Management</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-muted rounded">
                        <div>
                          <span className="text-sm font-medium">Database Size</span>
                          <p className="text-xs text-muted-foreground">PostgreSQL</p>
                        </div>
                        <span className="text-sm">2.4 GB</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-muted rounded">
                        <div>
                          <span className="text-sm font-medium">Last Backup</span>
                          <p className="text-xs text-muted-foreground">Automated</p>
                        </div>
                        <span className="text-sm">2 hours ago</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-muted rounded">
                        <div>
                          <span className="text-sm font-medium">Active Connections</span>
                          <p className="text-xs text-muted-foreground">Current</p>
                        </div>
                        <span className="text-sm">23/100</span>
                      </div>
                    </div>

                    <div className="mt-4 space-y-2">
                      <Button className="w-full" variant="outline">
                        <Database className="w-4 h-4 mr-2" />
                        Backup Database
                      </Button>
                      <Button className="w-full" variant="outline">
                        Export System Logs
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
