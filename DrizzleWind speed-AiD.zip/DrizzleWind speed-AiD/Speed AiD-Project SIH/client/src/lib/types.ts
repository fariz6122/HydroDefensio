export interface User {
  id: string;
  username: string;
  email: string;
  role: 'user' | 'health_official' | 'admin';
  firstName?: string;
  lastName?: string;
  phone?: string;
  location?: string;
  latitude?: string;
  longitude?: string;
  notificationPreferences: {
    sms: boolean;
    email: boolean;
    whatsapp: boolean;
    push: boolean;
  };
}

export interface Disease {
  id: string;
  name: string;
  description?: string;
  symptoms: string[];
  prevention?: string;
  treatment?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  isWaterborne: boolean;
  incubationPeriod?: string;
}

export interface DiseaseCase {
  id: string;
  diseaseId: string;
  userId?: string;
  location: string;
  latitude?: string;
  longitude?: string;
  status: 'suspected' | 'confirmed' | 'recovered' | 'deceased';
  reportedDate: string;
  confirmedDate?: string;
  symptoms: string[];
  severity: string;
  source: string;
}

export interface Hospital {
  id: string;
  name: string;
  address: string;
  phone?: string;
  email?: string;
  website?: string;
  latitude: string;
  longitude: string;
  type: 'government' | 'private' | 'clinic' | 'specialized';
  services: string[];
  capacity?: number;
  currentOccupancy?: number;
  specializations: string[];
  emergencyServices: boolean;
  isActive: boolean;
}

export interface Appointment {
  id: string;
  userId: string;
  hospitalId: string;
  appointmentDate: string;
  purpose: string;
  status: 'scheduled' | 'confirmed' | 'completed' | 'cancelled';
  notes?: string;
  doctorName?: string;
  department?: string;
  reminderSent: boolean;
}

export interface WaterQualityData {
  id: string;
  sensorId: string;
  location: string;
  latitude: string;
  longitude: string;
  ph?: string;
  turbidity?: string;
  dissolvedOxygen?: string;
  ecoliCount?: number;
  temperature?: string;
  conductivity?: string;
  totalColiform?: number;
  chlorine?: string;
  timestamp: string;
  status: 'active' | 'maintenance' | 'offline';
}

export interface RiskArea {
  id: string;
  name: string;
  description?: string;
  latitude: string;
  longitude: string;
  radius: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  affectedDiseases: string[];
  population?: number;
  lastUpdated: string;
  isActive: boolean;
}

export interface Notification {
  id: string;
  userId?: string;
  title: string;
  message: string;
  type: 'alert' | 'reminder' | 'info' | 'emergency';
  priority: 'low' | 'medium' | 'high' | 'critical';
  channels: string[];
  status: 'pending' | 'sent' | 'delivered' | 'failed';
  targetAudience: 'individual' | 'area' | 'all';
  riskAreaId?: string;
  sentAt?: string;
  createdAt: string;
}

export interface HealthDiaryEntry {
  id: string;
  userId: string;
  date: string;
  symptoms: string[];
  severityLevel?: number;
  waterConsumption?: string;
  waterSource?: string;
  foodIntake?: string;
  activities?: string;
  mood?: string;
  notes?: string;
  location?: string;
}

export interface WeatherData {
  id: string;
  location: string;
  latitude: string;
  longitude: string;
  temperature?: string;
  humidity?: string;
  rainfall?: string;
  windSpeed?: string;
  pressure?: string;
  conditions?: string;
  timestamp: string;
}

export interface DashboardStats {
  activeCases: number;
  highRiskAreas: number;
  waterQualityIndex: number;
  hospitalsAvailable: number;
}

export interface SymptomAssessment {
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  possibleDiseases: string[];
  recommendations: string[];
  urgency: 'none' | 'monitor' | 'consult' | 'immediate';
  score: number;
}

export interface RiskAssessment {
  personalRisk: number;
  areaRisk: number;
  overallRisk: number;
  factors: string[];
}

export interface WeatherResponse {
  location: string;
  latitude: number;
  longitude: number;
  temperature: number;
  humidity: number;
  rainfall: number;
  windSpeed: number;
  pressure: number;
  conditions: string;
  timestamp: Date;
}

export interface EmergencyAlertResult {
  email: number;
  sms: number;
  whatsapp: number;
  total: number;
}
